<?php
/**
 * Index file
 *
 * @package Kemet
 * @since Kemet 1.0.0
 */

/* Silence is golden, and we agree. */
