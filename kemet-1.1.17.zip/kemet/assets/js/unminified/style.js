/**
 * Flexibility is a JavaScript polyfill for Flexbox By Jonathan Neal, 10up. (https://github.com/jonathantneal/flexibility)
 * Licensed under MIT ( https://github.com/jonathantneal/flexibility/blob/master/LICENSE.md )
 */

!(function () {
  (window.flexibility = {}),
    Array.prototype.forEach ||
    (Array.prototype.forEach = function (t) {
      if (void 0 === this || null === this)
        throw new TypeError(this + "is not an object");
      if (!(t instanceof Function))
        throw new TypeError(t + " is not a function");
      for (
        var e = Object(this),
        i = arguments[1],
        n = e instanceof String ? e.split("") : e,
        r = Math.max(Math.min(n.length, 9007199254740991), 0) || 0,
        o = -1;
        ++o < r;

      )
        o in n && t.call(i, n[o], o, e);
    }),
    (function (t, e) {
      "function" == typeof define && define.amd
        ? define([], e)
        : "object" == typeof exports
          ? (module.exports = e())
          : (t.computeLayout = e());
    })(flexibility, function () {
      var t = (function () {
        function t(e) {
          if (
            ((!e.layout || e.isDirty) &&
              (e.layout = {
                width: void 0,
                height: void 0,
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
              }),
              e.style || (e.style = {}),
              e.children || (e.children = []),
              e.style.measure && e.children && e.children.length)
          )
            throw new Error(
              "Using custom measure function is supported only for leaf nodes."
            );
          return e.children.forEach(t), e;
        }

        function e(t) {
          return void 0 === t;
        }

        function i(t) {
          return t === q || t === G;
        }

        function n(t) {
          return t === U || t === Z;
        }

        function r(t, e) {
          if (void 0 !== t.style.marginStart && i(e))
            return t.style.marginStart;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.marginLeft;
              break;
            case "row-reverse":
              n = t.style.marginRight;
              break;
            case "column":
              n = t.style.marginTop;
              break;
            case "column-reverse":
              n = t.style.marginBottom;
          }
          return void 0 !== n
            ? n
            : void 0 !== t.style.margin
              ? t.style.margin
              : 0;
        }

        function o(t, e) {
          if (void 0 !== t.style.marginEnd && i(e)) return t.style.marginEnd;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.marginRight;
              break;
            case "row-reverse":
              n = t.style.marginLeft;
              break;
            case "column":
              n = t.style.marginBottom;
              break;
            case "column-reverse":
              n = t.style.marginTop;
          }
          return null != n ? n : void 0 !== t.style.margin ? t.style.margin : 0;
        }

        function l(t, e) {
          if (
            void 0 !== t.style.paddingStart &&
            t.style.paddingStart >= 0 &&
            i(e)
          )
            return t.style.paddingStart;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.paddingLeft;
              break;
            case "row-reverse":
              n = t.style.paddingRight;
              break;
            case "column":
              n = t.style.paddingTop;
              break;
            case "column-reverse":
              n = t.style.paddingBottom;
          }
          return null != n && n >= 0
            ? n
            : void 0 !== t.style.padding && t.style.padding >= 0
              ? t.style.padding
              : 0;
        }

        function a(t, e) {
          if (void 0 !== t.style.paddingEnd && t.style.paddingEnd >= 0 && i(e))
            return t.style.paddingEnd;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.paddingRight;
              break;
            case "row-reverse":
              n = t.style.paddingLeft;
              break;
            case "column":
              n = t.style.paddingBottom;
              break;
            case "column-reverse":
              n = t.style.paddingTop;
          }
          return null != n && n >= 0
            ? n
            : void 0 !== t.style.padding && t.style.padding >= 0
              ? t.style.padding
              : 0;
        }

        function d(t, e) {
          if (
            void 0 !== t.style.borderStartWidth &&
            t.style.borderStartWidth >= 0 &&
            i(e)
          )
            return t.style.borderStartWidth;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.borderLeftWidth;
              break;
            case "row-reverse":
              n = t.style.borderRightWidth;
              break;
            case "column":
              n = t.style.borderTopWidth;
              break;
            case "column-reverse":
              n = t.style.borderBottomWidth;
          }
          return null != n && n >= 0
            ? n
            : void 0 !== t.style.borderWidth && t.style.borderWidth >= 0
              ? t.style.borderWidth
              : 0;
        }

        function s(t, e) {
          if (
            void 0 !== t.style.borderEndWidth &&
            t.style.borderEndWidth >= 0 &&
            i(e)
          )
            return t.style.borderEndWidth;
          var n = null;
          switch (e) {
            case "row":
              n = t.style.borderRightWidth;
              break;
            case "row-reverse":
              n = t.style.borderLeftWidth;
              break;
            case "column":
              n = t.style.borderBottomWidth;
              break;
            case "column-reverse":
              n = t.style.borderTopWidth;
          }
          return null != n && n >= 0
            ? n
            : void 0 !== t.style.borderWidth && t.style.borderWidth >= 0
              ? t.style.borderWidth
              : 0;
        }

        function u(t, e) {
          return l(t, e) + d(t, e);
        }

        function y(t, e) {
          return a(t, e) + s(t, e);
        }

        function c(t, e) {
          return d(t, e) + s(t, e);
        }

        function f(t, e) {
          return r(t, e) + o(t, e);
        }

        function h(t, e) {
          return u(t, e) + y(t, e);
        }

        function m(t) {
          return t.style.justifyContent ? t.style.justifyContent : "flex-start";
        }

        function v(t) {
          return t.style.alignContent ? t.style.alignContent : "flex-start";
        }

        function p(t, e) {
          return e.style.alignSelf
            ? e.style.alignSelf
            : t.style.alignItems
              ? t.style.alignItems
              : "stretch";
        }

        function x(t, e) {
          if (e === N) {
            if (t === q) return G;
            if (t === G) return q;
          }
          return t;
        }

        function g(t, e) {
          var i;
          return (
            (i = t.style.direction ? t.style.direction : M),
            i === M && (i = void 0 === e ? A : e),
            i
          );
        }

        function b(t) {
          return t.style.flexDirection ? t.style.flexDirection : U;
        }

        function w(t, e) {
          return n(t) ? x(q, e) : U;
        }

        function W(t) {
          return t.style.position ? t.style.position : "relative";
        }

        function L(t) {
          return W(t) === tt && t.style.flex > 0;
        }

        function E(t) {
          return "wrap" === t.style.flexWrap;
        }

        function S(t, e) {
          return t.layout[ot[e]] + f(t, e);
        }

        function k(t, e) {
          return void 0 !== t.style[ot[e]] && t.style[ot[e]] >= 0;
        }

        function C(t, e) {
          return void 0 !== t.style[e];
        }

        function T(t) {
          return void 0 !== t.style.measure;
        }

        function $(t, e) {
          return void 0 !== t.style[e] ? t.style[e] : 0;
        }

        function H(t, e, i) {
          var n = {
            row: t.style.minWidth,
            "row-reverse": t.style.minWidth,
            column: t.style.minHeight,
            "column-reverse": t.style.minHeight,
          }[e],
            r = {
              row: t.style.maxWidth,
              "row-reverse": t.style.maxWidth,
              column: t.style.maxHeight,
              "column-reverse": t.style.maxHeight,
            }[e],
            o = i;
          return (
            void 0 !== r && r >= 0 && o > r && (o = r),
            void 0 !== n && n >= 0 && n > o && (o = n),
            o
          );
        }

        function z(t, e) {
          return t > e ? t : e;
        }

        function B(t, e) {
          void 0 === t.layout[ot[e]] &&
            k(t, e) &&
            (t.layout[ot[e]] = z(H(t, e, t.style[ot[e]]), h(t, e)));
        }

        function D(t, e, i) {
          e.layout[nt[i]] = t.layout[ot[i]] - e.layout[ot[i]] - e.layout[rt[i]];
        }

        function I(t, e) {
          return void 0 !== t.style[it[e]] ? $(t, it[e]) : -$(t, nt[e]);
        }

        function R(t, n, l, a) {
          var s = g(t, a),
            R = x(b(t), s),
            M = w(R, s),
            A = x(q, s);
          B(t, R),
            B(t, M),
            (t.layout.direction = s),
            (t.layout[it[R]] += r(t, R) + I(t, R)),
            (t.layout[nt[R]] += o(t, R) + I(t, R)),
            (t.layout[it[M]] += r(t, M) + I(t, M)),
            (t.layout[nt[M]] += o(t, M) + I(t, M));
          var N = t.children.length,
            lt = h(t, A),
            at = h(t, U);
          if (T(t)) {
            var dt = !e(t.layout[ot[A]]),
              st = F;
            (st = k(t, A) ? t.style.width : dt ? t.layout[ot[A]] : n - f(t, A)),
              (st -= lt);
            var ut = F;
            (ut = k(t, U)
              ? t.style.height
              : e(t.layout[ot[U]])
                ? l - f(t, A)
                : t.layout[ot[U]]),
              (ut -= h(t, U));
            var yt = !k(t, A) && !dt,
              ct = !k(t, U) && e(t.layout[ot[U]]);
            if (yt || ct) {
              var ft = t.style.measure(st, ut);
              yt && (t.layout.width = ft.width + lt),
                ct && (t.layout.height = ft.height + at);
            }
            if (0 === N) return;
          }
          var ht,
            mt,
            vt,
            pt,
            xt = E(t),
            gt = m(t),
            bt = u(t, R),
            wt = u(t, M),
            Wt = h(t, R),
            Lt = h(t, M),
            Et = !e(t.layout[ot[R]]),
            St = !e(t.layout[ot[M]]),
            kt = i(R),
            Ct = null,
            Tt = null,
            $t = F;
          Et && ($t = t.layout[ot[R]] - Wt);
          for (var Ht = 0, zt = 0, Bt = 0, Dt = 0, It = 0, Rt = 0; N > zt;) {
            var jt,
              Ft,
              Mt = 0,
              At = 0,
              Nt = 0,
              qt = 0,
              Gt = (Et && gt === O) || (!Et && gt !== _),
              Ut = Gt ? N : Ht,
              Zt = !0,
              Ot = N,
              _t = null,
              Jt = null,
              Kt = bt,
              Pt = 0;
            for (ht = Ht; N > ht; ++ht) {
              (vt = t.children[ht]),
                (vt.lineIndex = Rt),
                (vt.nextAbsoluteChild = null),
                (vt.nextFlexChild = null);
              var Qt = p(t, vt);
              if (Qt === Y && W(vt) === tt && St && !k(vt, M))
                vt.layout[ot[M]] = z(
                  H(vt, M, t.layout[ot[M]] - Lt - f(vt, M)),
                  h(vt, M)
                );
              else if (W(vt) === et)
                for (
                  null === Ct && (Ct = vt),
                  null !== Tt && (Tt.nextAbsoluteChild = vt),
                  Tt = vt,
                  mt = 0;
                  2 > mt;
                  mt++
                )
                  (pt = 0 !== mt ? q : U),
                    !e(t.layout[ot[pt]]) &&
                    !k(vt, pt) &&
                    C(vt, it[pt]) &&
                    C(vt, nt[pt]) &&
                    (vt.layout[ot[pt]] = z(
                      H(
                        vt,
                        pt,
                        t.layout[ot[pt]] -
                        h(t, pt) -
                        f(vt, pt) -
                        $(vt, it[pt]) -
                        $(vt, nt[pt])
                      ),
                      h(vt, pt)
                    ));
              var Vt = 0;
              if (
                (Et && L(vt)
                  ? (At++,
                    (Nt += vt.style.flex),
                    null === _t && (_t = vt),
                    null !== Jt && (Jt.nextFlexChild = vt),
                    (Jt = vt),
                    (Vt = h(vt, R) + f(vt, R)))
                  : ((jt = F),
                    (Ft = F),
                    kt
                      ? (Ft = k(t, U) ? t.layout[ot[U]] - at : l - f(t, U) - at)
                      : (jt = k(t, A)
                        ? t.layout[ot[A]] - lt
                        : n - f(t, A) - lt),
                    0 === Bt && j(vt, jt, Ft, s),
                    W(vt) === tt && (qt++, (Vt = S(vt, R)))),
                  xt && Et && Mt + Vt > $t && ht !== Ht)
              ) {
                qt--, (Bt = 1);
                break;
              }
              Gt && (W(vt) !== tt || L(vt)) && ((Gt = !1), (Ut = ht)),
                Zt &&
                (W(vt) !== tt ||
                  (Qt !== Y && Qt !== Q) ||
                  e(vt.layout[ot[M]])) &&
                ((Zt = !1), (Ot = ht)),
                Gt &&
                ((vt.layout[rt[R]] += Kt),
                  Et && D(t, vt, R),
                  (Kt += S(vt, R)),
                  (Pt = z(Pt, H(vt, M, S(vt, M))))),
                Zt && ((vt.layout[rt[M]] += Dt + wt), St && D(t, vt, M)),
                (Bt = 0),
                (Mt += Vt),
                (zt = ht + 1);
            }
            var Xt = 0,
              Yt = 0,
              te = 0;
            if (((te = Et ? $t - Mt : z(Mt, 0) - Mt), 0 !== At)) {
              var ee,
                ie,
                ne = te / Nt;
              for (Jt = _t; null !== Jt;)
                (ee = ne * Jt.style.flex + h(Jt, R)),
                  (ie = H(Jt, R, ee)),
                  ee !== ie && ((te -= ie), (Nt -= Jt.style.flex)),
                  (Jt = Jt.nextFlexChild);
              for (ne = te / Nt, 0 > ne && (ne = 0), Jt = _t; null !== Jt;)
                (Jt.layout[ot[R]] = H(Jt, R, ne * Jt.style.flex + h(Jt, R))),
                  (jt = F),
                  k(t, A)
                    ? (jt = t.layout[ot[A]] - lt)
                    : kt || (jt = n - f(t, A) - lt),
                  (Ft = F),
                  k(t, U)
                    ? (Ft = t.layout[ot[U]] - at)
                    : kt && (Ft = l - f(t, U) - at),
                  j(Jt, jt, Ft, s),
                  (vt = Jt),
                  (Jt = Jt.nextFlexChild),
                  (vt.nextFlexChild = null);
            } else
              gt !== O &&
                (gt === _
                  ? (Xt = te / 2)
                  : gt === J
                    ? (Xt = te)
                    : gt === K
                      ? ((te = z(te, 0)),
                        (Yt = At + qt - 1 !== 0 ? te / (At + qt - 1) : 0))
                      : gt === P && ((Yt = te / (At + qt)), (Xt = Yt / 2)));
            for (Kt += Xt, ht = Ut; zt > ht; ++ht)
              (vt = t.children[ht]),
                W(vt) === et && C(vt, it[R])
                  ? (vt.layout[rt[R]] = $(vt, it[R]) + d(t, R) + r(vt, R))
                  : ((vt.layout[rt[R]] += Kt),
                    Et && D(t, vt, R),
                    W(vt) === tt &&
                    ((Kt += Yt + S(vt, R)),
                      (Pt = z(Pt, H(vt, M, S(vt, M))))));
            var re = t.layout[ot[M]];
            for (St || (re = z(H(t, M, Pt + Lt), Lt)), ht = Ot; zt > ht; ++ht)
              if (((vt = t.children[ht]), W(vt) === et && C(vt, it[M])))
                vt.layout[rt[M]] = $(vt, it[M]) + d(t, M) + r(vt, M);
              else {
                var oe = wt;
                if (W(vt) === tt) {
                  var Qt = p(t, vt);
                  if (Qt === Y)
                    e(vt.layout[ot[M]]) &&
                      (vt.layout[ot[M]] = z(
                        H(vt, M, re - Lt - f(vt, M)),
                        h(vt, M)
                      ));
                  else if (Qt !== Q) {
                    var le = re - Lt - S(vt, M);
                    oe += Qt === V ? le / 2 : le;
                  }
                }
                (vt.layout[rt[M]] += Dt + oe), St && D(t, vt, M);
              }
            (Dt += Pt), (It = z(It, Kt)), (Rt += 1), (Ht = zt);
          }
          if (Rt > 1 && St) {
            var ae = t.layout[ot[M]] - Lt,
              de = ae - Dt,
              se = 0,
              ue = wt,
              ye = v(t);
            ye === X
              ? (ue += de)
              : ye === V
                ? (ue += de / 2)
                : ye === Y && ae > Dt && (se = de / Rt);
            var ce = 0;
            for (ht = 0; Rt > ht; ++ht) {
              var fe = ce,
                he = 0;
              for (mt = fe; N > mt; ++mt)
                if (((vt = t.children[mt]), W(vt) === tt)) {
                  if (vt.lineIndex !== ht) break;
                  e(vt.layout[ot[M]]) ||
                    (he = z(he, vt.layout[ot[M]] + f(vt, M)));
                }
              for (ce = mt, he += se, mt = fe; ce > mt; ++mt)
                if (((vt = t.children[mt]), W(vt) === tt)) {
                  var me = p(t, vt);
                  if (me === Q) vt.layout[rt[M]] = ue + r(vt, M);
                  else if (me === X)
                    vt.layout[rt[M]] = ue + he - o(vt, M) - vt.layout[ot[M]];
                  else if (me === V) {
                    var ve = vt.layout[ot[M]];
                    vt.layout[rt[M]] = ue + (he - ve) / 2;
                  } else me === Y && (vt.layout[rt[M]] = ue + r(vt, M));
                }
              ue += he;
            }
          }
          var pe = !1,
            xe = !1;
          if (
            (Et ||
              ((t.layout[ot[R]] = z(H(t, R, It + y(t, R)), Wt)),
                (R === G || R === Z) && (pe = !0)),
              St ||
              ((t.layout[ot[M]] = z(H(t, M, Dt + Lt), Lt)),
                (M === G || M === Z) && (xe = !0)),
              pe || xe)
          )
            for (ht = 0; N > ht; ++ht)
              (vt = t.children[ht]), pe && D(t, vt, R), xe && D(t, vt, M);
          for (Tt = Ct; null !== Tt;) {
            for (mt = 0; 2 > mt; mt++)
              (pt = 0 !== mt ? q : U),
                !e(t.layout[ot[pt]]) &&
                !k(Tt, pt) &&
                C(Tt, it[pt]) &&
                C(Tt, nt[pt]) &&
                (Tt.layout[ot[pt]] = z(
                  H(
                    Tt,
                    pt,
                    t.layout[ot[pt]] -
                    c(t, pt) -
                    f(Tt, pt) -
                    $(Tt, it[pt]) -
                    $(Tt, nt[pt])
                  ),
                  h(Tt, pt)
                )),
                C(Tt, nt[pt]) &&
                !C(Tt, it[pt]) &&
                (Tt.layout[it[pt]] =
                  t.layout[ot[pt]] - Tt.layout[ot[pt]] - $(Tt, nt[pt]));
            (vt = Tt),
              (Tt = Tt.nextAbsoluteChild),
              (vt.nextAbsoluteChild = null);
          }
        }

        function j(t, e, i, n) {
          t.shouldUpdate = !0;
          var r = t.style.direction || A,
            o =
              !t.isDirty &&
              t.lastLayout &&
              t.lastLayout.requestedHeight === t.layout.height &&
              t.lastLayout.requestedWidth === t.layout.width &&
              t.lastLayout.parentMaxWidth === e &&
              t.lastLayout.parentMaxHeight === i &&
              t.lastLayout.direction === r;
          o
            ? ((t.layout.width = t.lastLayout.width),
              (t.layout.height = t.lastLayout.height),
              (t.layout.top = t.lastLayout.top),
              (t.layout.left = t.lastLayout.left))
            : (t.lastLayout || (t.lastLayout = {}),
              (t.lastLayout.requestedWidth = t.layout.width),
              (t.lastLayout.requestedHeight = t.layout.height),
              (t.lastLayout.parentMaxWidth = e),
              (t.lastLayout.parentMaxHeight = i),
              (t.lastLayout.direction = r),
              t.children.forEach(function (t) {
                (t.layout.width = void 0),
                  (t.layout.height = void 0),
                  (t.layout.top = 0),
                  (t.layout.left = 0);
              }),
              R(t, e, i, n),
              (t.lastLayout.width = t.layout.width),
              (t.lastLayout.height = t.layout.height),
              (t.lastLayout.top = t.layout.top),
              (t.lastLayout.left = t.layout.left));
        }
        var F,
          M = "inherit",
          A = "ltr",
          N = "rtl",
          q = "row",
          G = "row-reverse",
          U = "column",
          Z = "column-reverse",
          O = "flex-start",
          _ = "center",
          J = "flex-end",
          K = "space-between",
          P = "space-around",
          Q = "flex-start",
          V = "center",
          X = "flex-end",
          Y = "stretch",
          tt = "relative",
          et = "absolute",
          it = {
            row: "left",
            "row-reverse": "right",
            column: "top",
            "column-reverse": "bottom",
          },
          nt = {
            row: "right",
            "row-reverse": "left",
            column: "bottom",
            "column-reverse": "top",
          },
          rt = {
            row: "left",
            "row-reverse": "right",
            column: "top",
            "column-reverse": "bottom",
          },
          ot = {
            row: "width",
            "row-reverse": "width",
            column: "height",
            "column-reverse": "height",
          };
        return {
          layoutNodeImpl: R,
          computeLayout: j,
          fillNodes: t,
        };
      })();
      return (
        "object" == typeof exports && (module.exports = t),
        function (e) {
          t.fillNodes(e), t.computeLayout(e);
        }
      );
    }),
    !window.addEventListener &&
    window.attachEvent &&
    (function () {
      (Window.prototype.addEventListener =
        HTMLDocument.prototype.addEventListener =
        Element.prototype.addEventListener =
        function (t, e) {
          this.attachEvent("on" + t, e);
        }),
        (Window.prototype.removeEventListener =
          HTMLDocument.prototype.removeEventListener =
          Element.prototype.removeEventListener =
          function (t, e) {
            this.detachEvent("on" + t, e);
          });
    })(),
    (flexibility.detect = function () {
      var t = document.createElement("p");
      try {
        return (t.style.display = "flex"), "flex" === t.style.display;
      } catch (e) {
        return !1;
      }
    }),
    !flexibility.detect() &&
    document.attachEvent &&
    document.documentElement.currentStyle &&
    document.attachEvent("onreadystatechange", function () {
      flexibility.onresize({
        target: document.documentElement,
      });
    }),
    (flexibility.init = function (t) {
      var e = t.onlayoutcomplete;
      return (
        e ||
        (e = t.onlayoutcomplete =
        {
          node: t,
          style: {},
          children: [],
        }),
        (e.style.display =
          t.currentStyle["-js-display"] || t.currentStyle.display),
        e
      );
    });
  var t,
    e = 1e3,
    i = 15,
    n = document.documentElement,
    r = 0,
    o = 0;
  flexibility.onresize = function (l) {
    if (n.clientWidth !== r || n.clientHeight !== o) {
      (r = n.clientWidth),
        (o = n.clientHeight),
        clearTimeout(t),
        window.removeEventListener("resize", flexibility.onresize);
      var a =
        l.target && 1 === l.target.nodeType
          ? l.target
          : document.documentElement;
      flexibility.walk(a),
        (t = setTimeout(function () {
          window.addEventListener("resize", flexibility.onresize);
        }, e / i));
    }
  };
  var l = {
    alignContent: {
      initial: "stretch",
      valid: /^(flex-start|flex-end|center|space-between|space-around|stretch)/,
    },
    alignItems: {
      initial: "stretch",
      valid: /^(flex-start|flex-end|center|baseline|stretch)$/,
    },
    boxSizing: {
      initial: "content-box",
      valid: /^(border-box|content-box)$/,
    },
    flexDirection: {
      initial: "row",
      valid: /^(row|row-reverse|column|column-reverse)$/,
    },
    flexWrap: {
      initial: "nowrap",
      valid: /^(nowrap|wrap|wrap-reverse)$/,
    },
    justifyContent: {
      initial: "flex-start",
      valid: /^(flex-start|flex-end|center|space-between|space-around)$/,
    },
  };
  flexibility.updateFlexContainerCache = function (t) {
    var e = t.style,
      i = t.node.currentStyle,
      n = t.node.style,
      r = {};
    (i["flex-flow"] || n["flex-flow"] || "").replace(
      /^(row|row-reverse|column|column-reverse)\s+(nowrap|wrap|wrap-reverse)$/i,
      function (t, e, i) {
        (r.flexDirection = e), (r.flexWrap = i);
      }
    );
    for (var o in l) {
      var a = o.replace(/[A-Z]/g, "-$&").toLowerCase(),
        d = l[o],
        s = i[a] || n[a];
      e[o] = d.valid.test(s) ? s : r[o] || d.initial;
    }
  };
  var a = {
    alignSelf: {
      initial: "auto",
      valid: /^(auto|flex-start|flex-end|center|baseline|stretch)$/,
    },
    boxSizing: {
      initial: "content-box",
      valid: /^(border-box|content-box)$/,
    },
    flexBasis: {
      initial: "auto",
      valid:
        /^((?:[-+]?0|[-+]?[0-9]*\.?[0-9]+(?:%|ch|cm|em|ex|in|mm|pc|pt|px|rem|vh|vmax|vmin|vw))|auto|fill|max-content|min-content|fit-content|content)$/,
    },
    flexGrow: {
      initial: 0,
      valid: /^\+?(0|[1-9][0-9]*)$/,
    },
    flexShrink: {
      initial: 0,
      valid: /^\+?(0|[1-9][0-9]*)$/,
    },
    order: {
      initial: 0,
      valid: /^([-+]?[0-9]+)$/,
    },
  };
  flexibility.updateFlexItemCache = function (t) {
    var e = t.style,
      i = t.node.currentStyle,
      n = t.node.style,
      r = {};
    (i.flex || n.flex || "").replace(/^\+?(0|[1-9][0-9]*)/, function (t) {
      r.flexGrow = t;
    });
    for (var o in a) {
      var l = o.replace(/[A-Z]/g, "-$&").toLowerCase(),
        d = a[o],
        s = i[l] || n[l];
      (e[o] = d.valid.test(s) ? s : r[o] || d.initial),
        "number" == typeof d.initial && (e[o] = parseFloat(e[o]));
    }
  };
  var d =
    "border:0 solid;clip:rect(0 0 0 0);display:inline-block;font:0/0 serif;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;overflow:hidden;padding:0;position:absolute;width:1em;",
    s = {
      medium: 4,
      none: 0,
      thick: 6,
      thin: 2,
    },
    u = {
      borderBottomWidth: 0,
      borderLeftWidth: 0,
      borderRightWidth: 0,
      borderTopWidth: 0,
      height: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
      paddingTop: 0,
      marginBottom: 0,
      marginLeft: 0,
      marginRight: 0,
      marginTop: 0,
      maxHeight: 0,
      maxWidth: 0,
      minHeight: 0,
      minWidth: 0,
      width: 0,
    },
    y = /^([-+]?0|[-+]?[0-9]*\.?[0-9]+)/,
    c = 100;
  (flexibility.updateLengthCache = function (t) {
    var e,
      i,
      n,
      r = t.node,
      o = t.style,
      l = r.parentNode,
      a = document.createElement("_"),
      f = a.runtimeStyle,
      h = r.currentStyle;
    (f.cssText = d + "font-size:" + h.fontSize),
      l.insertBefore(a, r.nextSibling),
      (o.fontSize = a.offsetWidth),
      (f.fontSize = o.fontSize + "px");
    for (var m in u) {
      var v = h[m];
      y.test(v) || ("auto" === v && !/(width|height)/i.test(m))
        ? /%$/.test(v)
          ? (/^(bottom|height|top)$/.test(m)
            ? (i || (i = l.offsetHeight), (n = i))
            : (e || (e = l.offsetWidth), (n = e)),
            (o[m] = (parseFloat(v) * n) / c))
          : ((f.width = v), (o[m] = a.offsetWidth))
        : /^border/.test(m) && v in s
          ? (o[m] = s[v])
          : delete o[m];
    }
    l.removeChild(a),
      "none" === h.borderTopStyle && (o.borderTopWidth = 0),
      "none" === h.borderRightStyle && (o.borderRightWidth = 0),
      "none" === h.borderBottomStyle && (o.borderBottomWidth = 0),
      "none" === h.borderLeftStyle && (o.borderLeftWidth = 0),
      o.width ||
      o.minWidth ||
      (/flex/.test(o.display)
        ? (o.width = r.offsetWidth)
        : (o.minWidth = r.offsetWidth)),
      o.height ||
      o.minHeight ||
      /flex/.test(o.display) ||
      (o.minHeight = r.offsetHeight);
  }),
    (flexibility.walk = function (t) {
      var e = flexibility.init(t),
        i = e.style,
        n = i.display;
      if ("none" === n) return {};
      var r = n.match(/^(inline)?flex$/);
      if (
        (r &&
          (flexibility.updateFlexContainerCache(e),
            (t.runtimeStyle.cssText =
              "display:" + (r[1] ? "inline-block" : "block")),
            (e.children = [])),
          Array.prototype.forEach.call(t.childNodes, function (t, n) {
            if (1 === t.nodeType) {
              var o = flexibility.walk(t),
                l = o.style;
              (o.index = n),
                r &&
                (flexibility.updateFlexItemCache(o),
                  "auto" === l.alignSelf && (l.alignSelf = i.alignItems),
                  (l.flex = l.flexGrow),
                  (t.runtimeStyle.cssText = "display:inline-block"),
                  e.children.push(o));
            }
          }),
          r)
      ) {
        e.children.forEach(function (t) {
          flexibility.updateLengthCache(t);
        }),
          e.children.sort(function (t, e) {
            return t.style.order - e.style.order || t.index - e.index;
          }),
          /-reverse$/.test(i.flexDirection) &&
          (e.children.reverse(),
            (i.flexDirection = i.flexDirection.replace(/-reverse$/, "")),
            "flex-start" === i.justifyContent
              ? (i.justifyContent = "flex-end")
              : "flex-end" === i.justifyContent &&
              (i.justifyContent = "flex-start")),
          flexibility.updateLengthCache(e),
          delete e.lastLayout,
          delete e.layout;
        var o = i.borderTopWidth,
          l = i.borderBottomWidth;
        (i.borderTopWidth = 0),
          (i.borderBottomWidth = 0),
          (i.borderLeftWidth = 0),
          "column" === i.flexDirection && (i.width -= i.borderRightWidth),
          flexibility.computeLayout(e),
          (t.runtimeStyle.cssText =
            "box-sizing:border-box;display:block;position:relative;width:" +
            (e.layout.width + i.borderRightWidth) +
            "px;height:" +
            (e.layout.height + o + l) +
            "px");
        var a = [],
          d = 1,
          s = "column" === i.flexDirection ? "width" : "height";
        e.children.forEach(function (t) {
          (a[t.lineIndex] = Math.max(a[t.lineIndex] || 0, t.layout[s])),
            (d = Math.max(d, t.lineIndex + 1));
        }),
          e.children.forEach(function (t) {
            var e = t.layout;
            "stretch" === t.style.alignSelf && (e[s] = a[t.lineIndex]),
              (t.node.runtimeStyle.cssText =
                "box-sizing:border-box;display:block;position:absolute;margin:0;width:" +
                e.width +
                "px;height:" +
                e.height +
                "px;top:" +
                e.top +
                "px;left:" +
                e.left +
                "px");
          });
      }
      return e;
    });
})();

/**
 * File navigation.js
 *
 * Handles toggling the navigation menu for small screens and enables tab
 * support for dropdown menus.
 *
 * @package Kemet
 */

var isIE = false;
var isEdge = false;

/**
 * Get all of an element's parent elements up the DOM tree
 *
 * @param  {Node}   elem     The element.
 * @param  {String} selector Selector to match against [optional].
 * @return {Array}           The parent elements.
 */
var getParents = function (elem, selector) {
  // Element.matches() polyfill.
  if (!Element.prototype.matches) {
    Element.prototype.matches =
      Element.prototype.matchesSelector ||
      Element.prototype.mozMatchesSelector ||
      Element.prototype.msMatchesSelector ||
      Element.prototype.oMatchesSelector ||
      Element.prototype.webkitMatchesSelector ||
      function (s) {
        var matches = (this.document || this.ownerDocument).querySelectorAll(s),
          i = matches.length;
        while (--i >= 0 && matches.item(i) !== this) { }
        return i > -1;
      };
  }

  // Setup parents array.
  var parents = [];

  // Get matching parent elements.
  for (; elem && elem !== document; elem = elem.parentNode) {
    // Add matching parents to array.
    if (selector) {
      if (elem.matches(selector)) {
        parents.push(elem);
      }
    } else {
      parents.push(elem);
    }
  }
  return parents;
};

/* . */
/**
 * Toggle Class funtion
 *
 * @param  {Node}   elem     The element.
 * @param  {String} selector Selector to match against [optional].
 * @return {Array}           The parent elements.
 */
var toggleClass = function (el, className) {
  if (el.classList.contains(className)) {
    el.classList.remove(className);
  } else {
    el.classList.add(className);
  }
};

// CustomEvent() constructor functionality in Internet Explorer 9 and higher.
(function () {
  // Internet Explorer 6-11
  isIE = /*@cc_on!@*/ false || !!document.documentMode;

  // Edge 20+
  isEdge = !isIE && !!window.StyleMedia;

  if (typeof window.CustomEvent === "function") return false;

  function CustomEvent(event, params) {
    params = params || { bubbles: false, cancelable: false, detail: undefined };
    var evt = document.createEvent("CustomEvent");
    evt.initCustomEvent(
      event,
      params.bubbles,
      params.cancelable,
      params.detail
    );
    return evt;
  }

  CustomEvent.prototype = window.Event.prototype;

  window.CustomEvent = CustomEvent;
})();

(function () {
  var setSubmenuPosition = function () {
    var menus = document.querySelectorAll(".main-header-bar-navigation");

    if (menus.length > 0) {
      for (var j = 0; j < menus.length; j++) {
        if ("undefined" !== typeof menus[j]) {
          var parentList = menus[j].querySelectorAll("ul.main-header-menu li");
          for (var i = 0; i < parentList.length; i++) {
            if (null != parentList[i].querySelector(".sub-menu, .children")) {
              var menuLeft = parentList[i].getBoundingClientRect().left,
                windowWidth = window.innerWidth,
                menuFromLeft = parseInt(windowWidth) - parseInt(menuLeft),
                menuGoingOutside = false;

              if (menuFromLeft < 200) {
                menuGoingOutside = true;
              }

              // Submenu items goes outside?
              if (menuGoingOutside) {
                parentList[i].classList.add("kmt-left-align-sub-menu");

                var all_submenu_parents = parentList[i].querySelectorAll(
                  ".menu-item-has-children, .page_item_has_children"
                );
                for (var k = 0; k < all_submenu_parents.length; k++) {
                  all_submenu_parents[k].classList.add(
                    "kmt-left-align-sub-menu"
                  );
                }
              }

              // Submenu Container goes to outside?
              if (menuFromLeft < 240) {
                parentList[i].classList.add("kmt-sub-menu-goes-outside");
              }
            }
          }
        }
      }
    }
  };
  setSubmenuPosition();
  var initKemetPopup = {
    header: "",
    init: function () {
      window.addEventListener("load", function () {
        initKemetPopup.initPopup();
        initKemetPopup.initMenu();
        initKemetPopup.enableDisplay();
      });
      window.addEventListener("resize", function () {
        initKemetPopup.initPopup();
        initKemetPopup.enableDisplay();
        initKemetPopup.closePopup();
      });
      document.addEventListener("kmtPartialContentRendered", function () {
        initKemetPopup.initPopup();
        initKemetPopup.initMenu();
        initKemetPopup.enableDisplay();
      });
    },
    initMenu: function () {
      var popupContainer = document.querySelectorAll(".kmt-popup-main");

      if (popupContainer.length > 0) {
        for (var i = 0; i < popupContainer.length; i++) {
          if ("undefined" !== typeof popupContainer[i]) {
            var popupMenu = popupContainer[i].querySelectorAll(
              ".main-header-bar-navigation"
            );

            if (popupMenu.length > 0) {
              for (var j = 0; j < popupMenu.length; j++) {
                if ("undefined" !== typeof popupMenu[j]) {
                  var parentList = popupMenu[j].querySelectorAll(
                    "ul.main-header-menu li"
                  );
                  initKemetPopup.KemetNavigationMenu(parentList);

                  var kemetMenuToggle = popupMenu[j].querySelectorAll(
                    "ul.main-header-menu .kmt-menu-toggle"
                  );
                  initKemetPopup.KemetToggleMenu(kemetMenuToggle);
                }
              }
            }
          }
        }
      }
    },
    initPopup: function () {
      var headerType =
        kemet.break_point <= window.innerWidth ? "desktop" : "mobile";

      initKemetPopup.header = headerType;
      var header = document.querySelector(
        "#kmt-" + initKemetPopup.header + "-header"
      ),
        popupContainer = document.querySelector(
          "#kmt-" + initKemetPopup.header + "-popup"
        ),
        popupToggleOpen = header.querySelector(".header-toggle-button"),
        popupToggleClose = popupContainer.querySelector(".toggle-button-close"),
        popupOverlay = popupContainer.querySelector(".kmt-popup-overlay");

      if (popupToggleOpen !== null) {
        window.addEventListener("click", function (e) {
          if (
            !popupToggleOpen.contains(e.target) &&
            popupToggleOpen.classList.contains("toggled") &&
            !e.target.classList.contains("kmt-menu-toggle")
          ) {
            popupToggleOpen.classList.remove("toggled");
          }
        });

        popupToggleOpen.addEventListener("click", function (event) {
          event.preventDefault();
          initKemetPopup.menuToggle(popupToggleOpen);
        });
      }

      if (popupToggleClose !== null) {
        popupToggleClose.addEventListener("click", function (event) {
          event.preventDefault();
          initKemetPopup.closePopup();
        });
      }

      if (popupOverlay !== null) {
        popupOverlay.addEventListener("click", function (event) {
          event.preventDefault();
          initKemetPopup.closePopup();
        });
      }
    },
    KemetNavigationMenu: function (parentList) {
      for (var i = 0; i < parentList.length; i++) {
        if (null != parentList[i].querySelector(".sub-menu, .children")) {
          // Insert Toggle Button.
          if (parentList[i].querySelectorAll(".kmt-menu-toggle").length <= 0) {
            var toggleButton = document.createElement("BUTTON"); // Create a <button> element
            toggleButton.setAttribute("role", "button");
            toggleButton.setAttribute("class", "kmt-menu-toggle");
            toggleButton.setAttribute("aria-expanded", "false");
            toggleButton.innerHTML =
              "<span class='screen-reader-text'>Menu Toggle</span>";

            var link = parentList[i].querySelector("a");
            var arrow = parentList[i].querySelector(".kmt-svg-icon.icon-dropdown-menu");
            if (arrow) {
              var wrap = document.createElement("div");
              wrap.setAttribute("class", "kmt-menu-item-wrap");
              parentList[i].insertBefore(wrap, parentList[i].childNodes[0]);
              wrap.appendChild(link);
              toggleButton.appendChild(arrow);
              wrap.appendChild(toggleButton);
            }
          }
        }
      }
    },
    KemetToggleMenu: function (kemetMenuToggle) {
      /* Submenu button click */
      for (var i = 0; i < kemetMenuToggle.length; i++) {
        kemetMenuToggle[i].onclick = function (event) {
          event.preventDefault();

          var parentLi = this.parentNode.parentNode;

          var parentLiChild = parentLi.querySelectorAll(
            ".menu-item-has-children, .page_item_has_children"
          );
          for (var j = 0; j < parentLiChild.length; j++) {
            parentLiChild[j].classList.remove("kmt-submenu-expanded");
            var parentLiChildSubMenu = parentLiChild[j].querySelector(
              ".sub-menu, .children"
            );
            parentLiChildSubMenu.style.display = "none";
          }

          var parentLiSibling = parentLi.parentNode.querySelectorAll(
            ".menu-item-has-children, .page_item_has_children"
          );
          for (var j = 0; j < parentLiSibling.length; j++) {
            if (parentLiSibling[j] != parentLi) {
              parentLiSibling[j].classList.remove("kmt-submenu-expanded");
              var allSubMenu = parentLiSibling[j].querySelectorAll(
                ".sub-menu, .children"
              );
              for (var k = 0; k < allSubMenu.length; k++) {
                allSubMenu[k].style.display = "none";
              }
            }
          }

          if (
            parentLi.classList.contains("menu-item-has-children") ||
            parentLi.classList.contains("page_item_has_children")
          ) {
            toggleClass(parentLi, "kmt-submenu-expanded");
            if (parentLi.classList.contains("kmt-submenu-expanded")) {
              parentLi.querySelector(".sub-menu, .children").style.display =
                "block";
            } else {
              parentLi.querySelector(".sub-menu, .children").style.display =
                "none";
            }
          }
        };
      }
    },
    menuToggle: function (popupToggleOpen) {
      var popupContainer = document.querySelector(
        "#kmt-" + initKemetPopup.header + "-popup"
      ),
        popupMenu = popupContainer.querySelectorAll(
          ".main-header-bar-navigation"
        );

      popupContainer.classList.add("active");

      popupToggleOpen.classList.add("toggled");
      if (popupMenu.length > 0) {
        for (var i = 0; i < popupMenu.length; i++) {
          if ("undefined" === typeof popupMenu[i]) {
            return false;
          }

          var menuHasChildren = popupMenu[i].querySelectorAll(
            ".menu-item-has-children, .page_item_has_children"
          );
          for (var x = 0; x < menuHasChildren.length; x++) {
            menuHasChildren[x].classList.remove("kmt-submenu-expanded");
            var menuHasChildrenSubMenu = menuHasChildren[x].querySelectorAll(
              ".sub-menu, .children"
            );
            for (var j = 0; j < menuHasChildrenSubMenu.length; j++) {
              menuHasChildrenSubMenu[j].style.display = "none";
            }
          }

          popupMenu[i].classList.add("toggle-on");
          if (popupMenu[i].classList.contains("toggle-on")) {
            popupMenu[i].style.display = "block";
          } else {
            popupMenu[i].style.display = "";
          }
        }
      }
    },
    closePopup: function () {
      var header = document.querySelector(
        "#kmt-" + initKemetPopup.header + "-header"
      ),
        popupContainer = document.querySelector(
          "#kmt-" + initKemetPopup.header + "-popup"
        ),
        popupToggleOpen = header.querySelector(".header-toggle-button"),
        popupMenu = popupContainer.querySelectorAll(
          ".main-header-bar-navigation"
        );

      if (popupToggleOpen !== null) {
        popupToggleOpen.classList.remove("toggled");
      }

      if (popupContainer !== null) {
        popupContainer.classList.remove("active");
      }
      if (popupMenu.length > 0) {
        for (var i = 0; i < popupMenu.length; i++) {
          popupMenu[i].classList.remove("toggle-on");

          popupMenu[i].style.display = "none";
        }
      }
    },
    enableDisplay: function () {
      var popupContainer = document.querySelector(
        "#kmt-" + initKemetPopup.header + "-popup"
      ),
        popupMenu = popupContainer.querySelectorAll(
          ".main-header-bar-navigation"
        );
      if (popupMenu.length > 0) {
        for (var i = 0; i < popupMenu.length; i++) {
          if (null != popupMenu[i]) {
            popupMenu[i].classList.remove("toggle-on");
            popupMenu[i].style.display = "";
          }

          var sub_menu = popupMenu[i].getElementsByClassName("sub-menu");
          for (var j = 0; j < sub_menu.length; j++) {
            sub_menu[j].style.display = "";
          }
          var child_menu = popupMenu[i].getElementsByClassName("children");
          for (var k = 0; k < child_menu.length; k++) {
            child_menu[k].style.display = "";
          }

          var searchIcons = popupMenu[i].getElementsByClassName(
            "kmt-search-menu-icon"
          );
          for (var l = 0; l < searchIcons.length; l++) {
            searchIcons[l].classList.remove("kmt-dropdown-active");
            searchIcons[l].style.display = "";
          }
        }
      }
    },
  };

  if ("loading" === document.readyState) {
    // The DOM has not yet been loaded.
    document.addEventListener("DOMContentLoaded", initKemetPopup.init);
  } else {
    // The DOM has already been loaded.
    initKemetPopup.init();
  }

  /* Add break point Class and related trigger */
  var updateHeaderBreakPoint = function () {
    var break_point = kemet.break_point,
      popupToggleOpen = document.querySelector(".header-toggle-button"),
      headerWrap = document.querySelectorAll("#kmt-mobile-header");

    if (headerWrap.length > 0) {
      for (var i = 0; i < headerWrap.length; i++) {
        if (headerWrap[i].tagName == "DIV") {
          var header_content_bp = window
            .getComputedStyle(headerWrap[i], "::before")
            .getPropertyValue("content");

          // Edge/Explorer header break point.
          if (isEdge || isIE || header_content_bp === "normal") {
            if (window.innerWidth <= break_point) {
              header_content_bp = break_point;
            }
          }

          header_content_bp = header_content_bp.replace(/[^0-9]/g, "");
          header_content_bp = parseInt(header_content_bp);

          // `kmt-header-break-point` class will use for Responsive Style of Header.
          if (header_content_bp != break_point) {
            //remove menu toggled class.
            if (null != popupToggleOpen) {
              popupToggleOpen.classList.remove("toggled");
            }
            document.body.classList.remove("kmt-header-break-point");
            var responsive_enabled = new CustomEvent(
              "kemet-header-responsive-enabled"
            );
            document.body.dispatchEvent(responsive_enabled);
          } else {
            document.body.classList.add("kmt-header-break-point");
            var responsive_disabled = new CustomEvent(
              "kemet-header-responsive-disabled"
            );
            document.body.dispatchEvent(responsive_disabled);
          }
        }
      }
    }
  };

  window.addEventListener("resize", function () {
    updateHeaderBreakPoint();
  });
  updateHeaderBreakPoint();

  var get_browser = function () {
    var ua = navigator.userAgent,
      tem,
      M =
        ua.match(
          /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i
        ) || [];
    if (/trident/i.test(M[1])) {
      tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
      return;
    }
    if ("Chrome" === M[1]) {
      tem = ua.match(/\bOPR|Edge\/(\d+)/);
      if (tem != null) {
        return;
      }
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, "-?"];
    if ((tem = ua.match(/version\/(\d+)/i)) != null) {
      M.splice(1, 1, tem[1]);
    }

    bodyElement = document.body;
    if ("Safari" === M[0] && M[1] < 11) {
      bodyElement.classList.add("kmt-safari-browser-less-than-11");
    }
  };

  get_browser();

  var setSearchPosition = function () {
    var sibling = document.querySelector('.kmt-search-menu-icon');
    if (!sibling) {
      return;
    }
    var searchIcon = document.querySelector(".kmt-search-icon"),
      searchLeft = searchIcon.getBoundingClientRect().left,
      windowWidth = window.innerWidth,
      searchFromLeft = parseInt(windowWidth) / 2;

    if (searchLeft < searchFromLeft) {
      sibling.classList.add("kmt-search-left");
    } else {
      sibling.classList.add("kmt-search-right");
    }

  }

  setSearchPosition();
  /* Search Script */
  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("kemet-search-icon")) {
      e.preventDefault();
      var sibling = e.target.parentNode.parentNode.querySelector(
        ".kmt-search-menu-icon"
      );
      setSearchPosition();
      if (!sibling.classList.contains("kmt-dropdown-active")) {
        sibling.classList.add("kmt-dropdown-active");
        sibling
          .querySelector(".search-field")
          .setAttribute("autocomplete", "off");
        setTimeout(function () {
          sibling.querySelector(".search-field").focus();
        }, 200);
      } else {
        sibling.classList.remove("kmt-dropdown-active");
      }
    }
  });

  /* Hide Dropdown on body click*/
  document.body.onclick = function (event) {
    if (
      !event.target.classList.contains("kmt-search-menu-icon") &&
      getParents(event.target, ".kmt-search-menu-icon").length === 0 &&
      getParents(event.target, ".kmt-search-icon").length === 0
    ) {
      var dropdownSearchWrap = document.getElementsByClassName(
        "kmt-search-menu-icon"
      );

      for (var i = 0; i < dropdownSearchWrap.length; i++) {
        dropdownSearchWrap[i].classList.remove("kmt-dropdown-active");
      }
    }
  };
  /**
   * Navigation Keyboard Navigation.
   */
  var container, button, menu, links, subMenus, i, len;

  container = document.getElementById("site-navigation");
  if (!container) {
    return;
  }

  button = container.getElementsByTagName("button")[0];
  if ("undefined" === typeof button) {
    return;
  }

  menu = container.getElementsByTagName("ul")[0];

  // Hide menu toggle button if menu is empty and return early.
  if ("undefined" === typeof menu) {
    button.style.display = "none";
    return;
  }

  menu.setAttribute("aria-expanded", "false");
  if (-1 === menu.className.indexOf("nav-menu")) {
    menu.className += " nav-menu";
  }

  button.onclick = function () {
    if (-1 !== container.className.indexOf("toggled")) {
      container.className = container.className.replace(" toggled", "");
      button.setAttribute("aria-expanded", "false");
      menu.setAttribute("aria-expanded", "false");
    } else {
      container.className += " toggled";
      button.setAttribute("aria-expanded", "true");
      menu.setAttribute("aria-expanded", "true");
    }
  };

  // Get all the link elements within the menu.
  links = menu.getElementsByTagName("a");
  subMenus = menu.getElementsByTagName("ul");

  // Set menu items with submenus to aria-haspopup="true".
  for (i = 0, len = subMenus.length; i < len; i++) {
    subMenus[i].parentNode.setAttribute("aria-haspopup", "true");
  }

  // Each time a menu link is focused or blurred, toggle focus.
  for (i = 0, len = links.length; i < len; i++) {
    links[i].addEventListener("focus", toggleFocus, true);
    links[i].addEventListener("blur", toggleFocus, true);
  }

  /**
   * Sets or removes .focus class on an element.
   */
  function toggleFocus() {
    var self = this;

    // Move up through the ancestors of the current link until we hit .nav-menu.
    while (-1 === self.className.indexOf("nav-menu")) {
      // On li elements toggle the class .focus.
      if ("li" === self.tagName.toLowerCase()) {
        if (-1 !== self.className.indexOf("focus")) {
          self.className = self.className.replace(" focus", "");
        } else {
          self.className += " focus";
        }
      }

      self = self.parentElement;
    }
  }

  /**
   * Toggles `focus` class to allow submenu access on tablets.
   */
  (function (container) {
    var touchStartFn,
      i,
      parentLink = container.querySelectorAll(
        ".menu-item-has-children > a, .page_item_has_children > a"
      );

    if ("ontouchstart" in window) {
      touchStartFn = function (e) {
        var menuItem = this.parentNode,
          i;

        if (!menuItem.classList.contains("focus")) {
          e.preventDefault();
          for (i = 0; i < menuItem.parentNode.children.length; ++i) {
            if (menuItem === menuItem.parentNode.children[i]) {
              continue;
            }
            menuItem.parentNode.children[i].classList.remove("focus");
          }
          menuItem.classList.add("focus");
        } else {
          menuItem.classList.remove("focus");
        }
      };

      for (i = 0; i < parentLink.length; ++i) {
        parentLink[i].addEventListener("touchstart", touchStartFn, false);
      }
    }
  })(container);
})();

/**
 * File skip-link-focus-fix.js
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://github.com/Automattic/_s/pull/136
 *
 * @package Kemet
 */

(function () {
  var is_webkit = navigator.userAgent.toLowerCase().indexOf("webkit") > -1,
    is_opera = navigator.userAgent.toLowerCase().indexOf("opera") > -1,
    is_ie = navigator.userAgent.toLowerCase().indexOf("msie") > -1;

  if (
    (is_webkit || is_opera || is_ie) &&
    document.getElementById &&
    window.addEventListener
  ) {
    window.addEventListener(
      "hashchange",
      function () {
        var id = location.hash.substring(1),
          element;

        if (!/^[A-z0-9_-]+$/.test(id)) {
          return;
        }

        element = document.getElementById(id);

        if (element) {
          if (!/^(?:a|select|input|button|textarea)$/i.test(element.tagName)) {
            element.tabIndex = -1;
          }

          element.focus();
        }
      },
      false
    );
  }
})();

/**
 * Sticky Footer
 */
(function () {
  function parallaxFooter() {
    var $body = document.body;
    if ($body.classList.contains("kmt-sticky-footer")) {
      var $content = $body.querySelector("#content"),
        $stickFooter = $body.querySelector(".sticky-footer");
      setTimeout(function () {
        $content.style.marginBottom = $stickFooter.offsetHeight + "px";
      }, 1);
    }
  }

  window.addEventListener("resize", parallaxFooter());
  parallaxFooter();
})();
/**
 * scroll to top.
 */
(function () {
  var goTopBtn = document.getElementById("kmt-go-top");
  if (goTopBtn) {
    var checkScrollVisiblity = function () {
      if (window.scrollY > 100) {
        goTopBtn.classList.add('is-opacity');
      } else {
        goTopBtn.classList.remove('is-opacity');;
      }
    }
    window.addEventListener('scroll', checkScrollVisiblity);
    checkScrollVisiblity();
    // Scroll to top on click.
    goTopBtn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
})();
/**
 * Sticky Sidebar
 */
(function () {
  function stickySidebar() {
    var $body = document.body,
      offsetTop = 0;
    if (
      $body.classList.contains("kmt-sticky-sidebar") ||
      $body.classList.contains("kmt-sticky-sidebar-widget")
    ) {
      if (!$body.querySelector("#primary") || !$body.querySelector("#secondary")) {
        return;
      }

      var primaryHeight = $body.querySelector("#primary").offsetHeight;
      var secondary = $body.querySelector("#secondary");

      if (secondary.offsetHeight < primaryHeight) {
        secondary.style.height = primaryHeight + "px";
      }

      if ($body.classList.contains("admin-bar")) {
        offsetTop += 32;
      }
      var header = $body.querySelector("#sitehead");
      if (header.classList.contains("kmt-sticky-header")) {
        offsetTop += header.offsetHeight;
      }

      if ($body.classList.contains("kmt-sticky-sidebar")) {
        var sidebar = $body.querySelector("#secondary .sidebar-main");
        if (sidebar) {
          sidebar.style.top = Math.floor(offsetTop) + "px";
          sidebar.style.maxHeight =
            "calc( 100vh - " + Math.floor(offsetTop) + "px )";
        }
      }

      if ($body.classList.contains("kmt-sticky-sidebar-widget")) {
        var lastWidget = $body.querySelector(
          "#secondary .sidebar-main .widget:last-child"
        );
        if (lastWidget) {
          lastWidget.style.top = Math.floor(offsetTop) + "px";
          lastWidget.style.maxHeight =
            "calc( 100vh - " + Math.floor(offsetTop) + "px )";
        }
      }
    }
  }

  document.addEventListener("scroll", function (e) {
    stickySidebar();
  });
  stickySidebar();

  // cart popup
  let cartBtn = document.querySelector('.kmt-cart-tigger');
  if (cartBtn) {
    let popup = document.querySelector('#kmt-cart-popup');
    let closeBtn = popup.querySelector('#kmt-toggle-button-close');
    let overlay = popup.querySelector('.kmt-popup-overlay');
    cartBtn.addEventListener('click', function (e) {
      e.preventDefault();
      popup.classList.add("active");
    });
    closeBtn.addEventListener('click', function () {
      close_popup();
    });
    overlay.addEventListener('click', function () {
      close_popup();
    });
    function close_popup() {
      popup.classList.remove('active');
    }
  }
})();
