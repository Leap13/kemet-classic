<?php
/**
 * Draw Live Customizer Toggle Control
 */
?>

<div class="essb-customizer-toggle" title="<?php _e('Quick Setup of Your Social Share Buttons', 'essb'); ?>">
	<div class="essb-customizer-icon essb-customizer-icon-size"></div>
</div>

<div class="preloader-holder">
	<div class="preloader"></div>
	<div class="preloader-message">Please Wait a Moment ...</div>
</div>