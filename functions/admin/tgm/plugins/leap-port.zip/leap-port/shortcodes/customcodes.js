( function () {

    tinymce.create( 'tinymce.plugins.Addshortcodes', {
        init: function ( ed, url ) {

            //Add Video
            ed.addButton( 'AddVideo', {
                title: 'Add Video(Youtube / Vimeo / Dailymotion) shortcode',
                cmd: 'leap_video',
                image: url + '/images/video.svg'
            } );
            ed.addCommand( 'leap_video', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_video', width: 500, height: 500, inline: 1 } );
            } );

            //Add SoundCloud
            ed.addButton( 'AddSoundcloud', {
                title: 'Add a SoundCloud shortcode',
                cmd: 'leap_soundcloud',
                image: url + '/images/soundcloud.svg'
            } );
            ed.addCommand( 'leap_soundcloud', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_soundcloud', width: 500, height: 500, inline: 1 } );
            } );

            //Add Button
            ed.addButton( 'AddButton', {
                title: 'Add button shortcode',
                cmd: 'leap_button',
                image: url + '/images/button.svg'
            } );
            ed.addCommand( 'leap_button', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_button', width: 600, height: 500, inline: 1 } );
            } );

            //Add Dropcap
            ed.addButton( 'AddDropcap', {
                title: 'Add Dropcap shortcode',
                cmd: 'leap_dropcap',
                image: url + '/images/dropcap.svg'
            } );
            ed.addCommand( 'leap_dropcap', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_dropcap', width: 500, height: 250, inline: 1 } );
            } );

            //Add Highlight
            ed.addButton( 'AddHighlight', {
                title: 'Add Highlight shortcode',
                cmd: 'leap_highlight',
                image: url + '/images/highlight.svg'
            } );
            ed.addCommand( 'leap_highlight', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_highlight', width: 500, height: 250, inline: 1 } );
            } );

            //Add Googlefont
            ed.addButton( 'AddGooglefont', {
                title: 'Google Font shortcode',
                cmd: 'leap_google_font',
                image: url + '/images/googlefont.svg'
            } );
            ed.addCommand( 'leap_google_font', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_google_font', width: 500, height: 500, inline: 1 } );
            } );

            //Add Quote
            ed.addButton( 'AddQuote', {
                title: 'Add Quote shortcode',
                cmd: 'leap_quote',
                image: url + '/images/quote.svg'
            } );
            ed.addCommand( 'leap_quote', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_quote', width: 500, height: 250, inline: 1 } );
            } );

            //Add Content Boxes
            ed.addButton( 'AddIconbox', {
                title: 'Add Icon Box shortcode',
                cmd: 'leap_icon_box',
                image: url + '/images/iconbox.svg'
            } );
            ed.addCommand( 'leap_icon_box', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_icon_box', width: 500, height: 500, inline: 1 } );
            } );

            //Add Image Box
            ed.addButton( 'AddImagebox', {
                title: 'Add Image Box shortcode',
                cmd: 'leap_image_box',
                image: url + '/images/imagebox.svg'
            } );
            ed.addCommand( 'leap_image_box', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_image_box', width: 500, height: 500, inline: 1 } );
            } );

            //Add Tagline Boxes
            ed.addButton( 'AddTagline', {
                title: 'Add Tagline shortcode',
                cmd: 'leap_tagline',
                image: url + '/images/tagline.svg'
            } );
            ed.addCommand( 'leap_tagline', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_tagline', width: 500, height: 600, inline: 1 } );
            } );

            //Add One Half
            ed.addButton( 'AddOnehalf', {
                title: 'Add One Half shortcode',
                cmd: 'leap_onehalf',
                image: url + '/images/1-2.svg'
            } );
            ed.addCommand( 'leap_onehalf', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_onehalf', width: 500, height: 600, inline: 1 } );
            } );

            //Add One Third
            ed.addButton( 'AddOnethird', {
                title: 'Add One Third shortcode',
                cmd: 'leap_onethird',
                image: url + '/images/1-3.svg'
            } );
            ed.addCommand( 'leap_onethird', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_onethird', width: 500, height: 600, inline: 1 } );
            } );

            //Add Two Third
            ed.addButton( 'AddTwothird', {
                title: 'Add Two Third shortcode',
                cmd: 'leap_twothird',
                image: url + '/images/2-3.svg'
            } );
            ed.addCommand( 'leap_twothird', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_twothird', width: 500, height: 600, inline: 1 } );
            } );

            //Add One Fourth
            ed.addButton( 'AddOnefourth', {
                title: 'Add One Fourth shortcode',
                cmd: 'leap_onefourth',
                image: url + '/images/1-4.svg'
            } );
            ed.addCommand( 'leap_onefourth', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_onefourth', width: 500, height: 600, inline: 1 } );
            } );

            //Add Three Fourth
            ed.addButton( 'AddThreefourth', {
                title: 'Add Three Fourth shortcode',
                cmd: 'leap_threefourth',
                image: url + '/images/3-4.svg'
            } );
            ed.addCommand( 'leap_threefourth', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_threefourth', width: 500, height: 600, inline: 1 } );
            } );

            //Add Toggle
            ed.addButton( 'AddToggle', {
                title: 'Add Toggle shortcode',
                cmd: 'leap_toggle',
                image: url + '/images/toggle.svg'
            } );
            ed.addCommand( 'leap_toggle', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_toggle', width: 500, height: 600, inline: 1 } );
            } );

            //Add Accordion
            ed.addButton( 'AddAccordion', {
                title: 'Add Accordion shortcode',
                cmd: 'leap_accordion',
                image: url + '/images/accordion.svg'
            } );
            ed.addCommand( 'leap_accordion', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_accordion', width: 500, height: 600, inline: 1 } );
            } );

            //Add Recent Posts
            ed.addButton( 'AddRecentposts', {
                title: 'Add Recent Posts shortcode',
                cmd: 'leap_recentposts',
                image: url + '/images/recentpost.svg'
            } );
            ed.addCommand( 'leap_recentposts', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_recentposts', width: 500, height: 600, inline: 1 } );
            } );

            //Add Iframe
            ed.addButton( 'AddIframe', {
                title: 'Add Iframe shortcode',
                cmd: 'leap_iframe',
                image: url + '/images/iframe.svg'
            } );
            ed.addCommand( 'leap_iframe', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_iframe', width: 500, height: 600, inline: 1 } );
            } );

            //Add Lightbox
            ed.addButton( 'AddLightbox', {
                title: 'Add Lightbox shortcode',
                cmd: 'leap_lightbox',
                image: url + '/images/lightbox.svg'
            } );
            ed.addCommand( 'leap_lightbox', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_lightbox', width: 500, height: 600, inline: 1 } );
            } );

            //Add Title
            ed.addButton( 'AddTitle', {
                title: 'Add Title shortcode',
                cmd: 'leap_title',
                image: url + '/images/title.svg'
            } );
            ed.addCommand( 'leap_title', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_title', width: 500, height: 500, inline: 1 } );
            } );

            //Add Tabs
            ed.addButton( 'AddTabs', {
                title: 'Add Tabs shortcode',
                cmd: 'leap_tabs',
                image: url + '/images/tabs.svg'
            } );
            ed.addCommand( 'leap_tabs', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_tabs', width: 500, height: 400, inline: 1 } );
            } );

            //Add QR
            ed.addButton( 'AddQRCode', {
                title: 'Add QR Code shortcode',
                cmd: 'leap_qrcode',
                image: url + '/images/qr.svg'
            } );
            ed.addCommand( 'leap_qrcode', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_qrcode', width: 500, height: 300, inline: 1 } );
            } );

            //Add Separator
            ed.addButton( 'AddSeparator', {
                title: 'Add Separator shortcode',
                cmd: 'leap_separator',
                image: url + '/images/separator.svg'
            } );
            ed.addCommand( 'leap_separator', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_separator', width: 500, height: 300, inline: 1 } );
            } );

            //Add List
            ed.addButton( 'AddList', {
                title: 'Add List shortcode',
                cmd: 'leap_list',
                image: url + '/images/list.svg'
            } );
            ed.addCommand( 'leap_list', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_list', width: 500, height: 500, inline: 1 } );
            } );

            //Add Tooltip
            ed.addButton( 'AddTooltip', {
                title: 'Add Tooltip shortcode',
                cmd: 'leap_tooltip',
                image: url + '/images/tooltip.svg'
            } );
            ed.addCommand( 'leap_tooltip', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_tooltip', width: 500, height: 500, inline: 1 } );
            } );

            //Add Testimonials
            ed.addButton( 'AddTestimonials', {
                title: 'Add Testimonials shortcode',
                cmd: 'leap_testimonials',
                image: url + '/images/testimonial.svg'
            } );
            ed.addCommand( 'leap_testimonials', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_testimonials', width: 500, height: 500, inline: 1 } );
            } );

            //Add Progress Bar
            ed.addButton( 'AddProgressBar', {
                title: 'Add Progress Bar shortcode',
                cmd: 'leap_progress_bar',
                image: url + '/images/progressbar.svg'
            } );
            ed.addCommand( 'leap_progress_bar', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_progress_bar', width: 500, height: 500, inline: 1 } );
            } );

            //Add Alert Box
            ed.addButton( 'AddAlertBox', {
                title: 'Add Alert Box shortcode',
                cmd: 'leap_alert_box',
                image: url + '/images/alert.svg'
            } );
            ed.addCommand( 'leap_alert_box', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_alert_box', width: 500, height: 500, inline: 1 } );
            } );

            //Add Alert Box
            ed.addButton( 'AddFontawesome', {
                title: 'Add Font Awesome shortcode',
                cmd: 'leap_fontawesome',
                image: url + '/images/fontawesome.svg'
            } );
            ed.addCommand( 'leap_fontawesome', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_fontawesome', width: 500, height: 500, inline: 1 } );
            } );

            //Add Person
            ed.addButton( 'AddPerson', {
                title: 'Add Person shortcode',
                cmd: 'leap_person',
                image: url + '/images/person.svg'
            } );
            ed.addCommand( 'leap_person', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_person', width: 500, height: 600, inline: 1 } );
            } );

            //Add Flickr
            ed.addButton( 'AddFlickr', {
                title: 'Display photos from flicker shortcode',
                cmd: 'leap_flickr',
                image: url + '/images/flicker.svg'
            } );
            ed.addCommand( 'leap_flickr', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_flickr', width: 500, height: 500, inline: 1 } );
            } );

            //Add RSS
            ed.addButton( 'AddRss', {
                title: 'Display RSS feeds shortcode',
                cmd: 'leap_rss',
                image: url + '/images/feed.svg'
            } );
            ed.addCommand( 'leap_rss', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_rss', width: 500, height: 500, inline: 1 } );
            } );

            //Add Table
            ed.addButton( 'AddTable', {
                title: 'Add Table',
                cmd: 'leap_table',
                image: url + '/images/table.svg'
            } );
            ed.addCommand( 'leap_table', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_table', width: 500, height: 500, inline: 1 } );
            } );

            //Add Clients Slider
            ed.addButton( 'AddClients', {
                title: 'Add Clients Slider Shortcode',
                cmd: 'leap_clients',
                image: url + '/images/clients.svg'
            } );
            ed.addCommand( 'leap_clients', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_clients', width: 500, height: 250, inline: 1 } );
            } );

            //Add Clients Slider
            ed.addButton( 'AddPricingTable', {
                title: 'Add Pricing Table Shortcode',
                cmd: 'leap_pricing-table',
                image: url + '/images/pricingtable.svg'
            } );
            ed.addCommand( 'leap_pricing-table', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_pricing-table', width: 500, height: 400, inline: 1 } );
            } );

            //Add Full Width
            ed.addButton( 'AddFullWidth', {
                title: 'Add Full Width Container Shortcode',
                cmd: 'leap_full-width',
                image: url + '/images/fullwidth.svg'
            } );
            ed.addCommand( 'leap_full-width', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_full_width', width: 500, height: 400, inline: 1 } );
            } );

            //Add Blog
            ed.addButton( 'AddBlog', {
                title: 'Add Blog Shortcode',
                cmd: 'leap_blog',
                image: url + '/images/blog.svg'
            } );
            ed.addCommand( 'leap_blog', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_blog', width: 500, height: 400, inline: 1 } );
            } );

            //Add Blog
            ed.addButton( 'AddGap', {
                title: 'Add Gap Shortcode',
                cmd: 'leap_gap',
                image: url + '/images/gap.svg'
            } );
            ed.addCommand( 'leap_gap', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_gap', width: 500, height: 400, inline: 1 } );
            } );

            //Add Blog
            ed.addButton( 'AddImage', {
                title: 'Add Image shortcode',
                cmd: 'leap_image',
                image: url + '/images/imageframe.svg'
            } );
            ed.addCommand( 'leap_image', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_image', width: 500, height: 400, inline: 1 } );
            } );

            //Add Portfolio Slider
            ed.addButton( 'AddPortfolioSlider', {
                title: 'Add Portfolio Slider shortcode',
                cmd: 'leap_portfolio_slider',
                image: url + '/images/portfolio_slider.svg'
            } );
            ed.addCommand( 'leap_portfolio_slider', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_portfolio_slider', width: 500, height: 400, inline: 1 } );
            } );

            //Add Portfolio
            ed.addButton( 'AddPortfolio', {
                title: 'Add Portfolio shortcode',
                cmd: 'leap_portfolio',
                image: url + '/images/portfolio.svg'
            } );
            ed.addCommand( 'leap_portfolio', function () {
                ed.windowManager.open( { file: url + '/ui.php?page=leap_portfolio', width: 500, height: 400, inline: 1 } );
            } );




        },
        getInfo: function () {
            return {
                longname: "Leap13 Shortcodes",
                author: 'Leap13',
                authorurl: 'http://www.Leap13.com/',
                infourl: 'http://www.Leap13.com/',
                version: "1.0"
            };
        }
    } );
    tinymce.PluginManager.add( 'leap13ShortCodes', tinymce.plugins.Addshortcodes );

} )();