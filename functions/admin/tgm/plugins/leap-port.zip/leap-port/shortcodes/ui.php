<?php
$page       = htmlentities( $_GET[ 'page' ] );
?>
<!DOCTYPE html>
<head>
    <script type="text/javascript" src="../../../../wp-includes/js/jquery/jquery.js"></script>
    <script type="text/javascript" src="../../../../wp-includes/js/tinymce/tiny_mce_popup.js"></script>
    <link rel='stylesheet' href='vendor/bootstrap/css/bootstrap.min.css' type='text/css' media='all' />

    <?php
    $animations = '
<select class="form-control" id="animationtype" name="animationtype">
<option value=""></option>
  <optgroup label="Attention Seekers">
	<option value="bounce">bounce</option>
	<option value="flash">flash</option>
	<option value="pulse">pulse</option>
	<option value="rubberBand">rubberBand</option>
	<option value="shake">shake</option>
	<option value="swing">swing</option>
	<option value="tada">tada</option>
	<option value="wobble">wobble</option>
  </optgroup>

  <optgroup label="Bouncing Entrances">
	<option value="bounceIn">bounceIn</option>
	<option value="bounceInDown">bounceInDown</option>
	<option value="bounceInLeft">bounceInLeft</option>
	<option value="bounceInRight">bounceInRight</option>
	<option value="bounceInUp">bounceInUp</option>
  </optgroup>

  <optgroup label="Bouncing Exits">
	<option value="bounceOut">bounceOut</option>
	<option value="bounceOutDown">bounceOutDown</option>
	<option value="bounceOutLeft">bounceOutLeft</option>
	<option value="bounceOutRight">bounceOutRight</option>
	<option value="bounceOutUp">bounceOutUp</option>
  </optgroup>

  <optgroup label="Fading Entrances">
	<option value="fadeIn">fadeIn</option>
	<option value="fadeInDown">fadeInDown</option>
	<option value="fadeInDownBig">fadeInDownBig</option>
	<option value="fadeInLeft">fadeInLeft</option>
	<option value="fadeInLeftBig">fadeInLeftBig</option>
	<option value="fadeInRight">fadeInRight</option>
	<option value="fadeInRightBig">fadeInRightBig</option>
	<option value="fadeInUp">fadeInUp</option>
	<option value="fadeInUpBig">fadeInUpBig</option>
  </optgroup>

  <optgroup label="Fading Exits">
	<option value="fadeOut">fadeOut</option>
	<option value="fadeOutDown">fadeOutDown</option>
	<option value="fadeOutDownBig">fadeOutDownBig</option>
	<option value="fadeOutLeft">fadeOutLeft</option>
	<option value="fadeOutLeftBig">fadeOutLeftBig</option>
	<option value="fadeOutRight">fadeOutRight</option>
	<option value="fadeOutRightBig">fadeOutRightBig</option>
	<option value="fadeOutUp">fadeOutUp</option>
	<option value="fadeOutUpBig">fadeOutUpBig</option>
  </optgroup>

  <optgroup label="Flippers">
	<option value="flip">flip</option>
	<option value="flipInX">flipInX</option>
	<option value="flipInY">flipInY</option>
	<option value="flipOutX">flipOutX</option>
	<option value="flipOutY">flipOutY</option>
  </optgroup>

  <optgroup label="Lightspeed">
	<option value="lightSpeedIn">lightSpeedIn</option>
	<option value="lightSpeedOut">lightSpeedOut</option>
  </optgroup>

  <optgroup label="Rotating Entrances">
	<option value="rotateIn">rotateIn</option>
	<option value="rotateInDownLeft">rotateInDownLeft</option>
	<option value="rotateInDownRight">rotateInDownRight</option>
	<option value="rotateInUpLeft">rotateInUpLeft</option>
	<option value="rotateInUpRight">rotateInUpRight</option>
  </optgroup>

  <optgroup label="Rotating Exits">
	<option value="rotateOut">rotateOut</option>
	<option value="rotateOutDownLeft">rotateOutDownLeft</option>
	<option value="rotateOutDownRight">rotateOutDownRight</option>
	<option value="rotateOutUpLeft">rotateOutUpLeft</option>
	<option value="rotateOutUpRight">rotateOutUpRight</option>
  </optgroup>

  <optgroup label="Specials">
	<option value="hinge">hinge</option>
	<option value="rollIn">rollIn</option>
	<option value="rollOut">rollOut</option>
  </optgroup>

  <optgroup label="Zoom Entrances">
	<option value="zoomIn">zoomIn</option>
	<option value="zoomInDown">zoomInDown</option>
	<option value="zoomInLeft">zoomInLeft</option>
	<option value="zoomInRight">zoomInRight</option>
	<option value="zoomInUp">zoomInUp</option>
  </optgroup>

  <optgroup label="Zoom Exits">
	<option value="zoomOut">zoomOut</option>
	<option value="zoomOutDown">zoomOutDown</option>
	<option value="zoomOutLeft">zoomOutLeft</option>
	<option value="zoomOutRight">zoomOutRight</option>
	<option value="zoomOutUp">zoomOutUp</option>
  </optgroup>
</select>
';
    ?>


    <?php
    if ( $page == 'leap_video' ) {
        ?>

        <script type="text/javascript">
            var AddVideo = {
                e: '',
                init: function ( e ) {
                    AddVideo.e = e;
                    tinyMCEPopup.resizeToInnerSize();
                },
                insert: function createGalleryShortcode( e ) {

                    var video_type = jQuery( '#video_type' ).val();
                    var video_id = jQuery( '#video_id' ).val();
                    var width = jQuery( '#width' ).val();
                    var height = jQuery( '#height' ).val();


                    var output = '[leap_video ';

                    output += 'video_type="' + video_type + '" ';
                    output += 'video_id="' + video_id + '" ';
                    output += 'width="' + width + '" ';
                    output += 'height="' + height + '" ';

                    output += ']';
                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                    tinyMCEPopup.close();

                }
            }
            tinyMCEPopup.onInit.add( AddVideo.init, AddVideo );

        </script>
        <title>Add Video</title>

    </head>
    <body style="padding-top: 20px;"><div class="container">


            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddVideo.insert( AddVideo.e )">
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="video_type">Video Type</label>
                    <div class="col-sm-10">
                        <select class="form-control" id="video_type" name="video_type">
                            <option value="youtube" selected="selected">Youtube</option>
                            <option value="vimeo">Vimeo</option>
                            <option value="dailymotion">Dailymotion</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label" for="video_id">Video ID</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="video_id" name="video_id" type="text" value=""/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label" for="width">Width</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="width" name="width" type="text" value="550" />
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-2 control-label" for="height">Height</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="height" name="height" type="text" value="300"/>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                    </div>
                </div>

            </form>

            <?php
        } elseif ( $page == 'leap_soundcloud' ) {
            ?>

            <script type="text/javascript">
                var AddSoundcloud = {
                    e: '',
                    init: function ( e ) {
                        AddSoundcloud.e = e;
                        tinyMCEPopup.resizeToInnerSize();
                    },
                    insert: function createGalleryShortcode( e ) {

                        var url = jQuery( '#url' ).val();
                        var width = jQuery( '#width' ).val();
                        var height = jQuery( '#height' ).val();
                        var comments = jQuery( '#comments' ).val();
                        var auto_play = jQuery( '#auto_play' ).val();


                        var output = '[leap_soundcloud ';

                        output += 'url="' + url + '" ';
                        output += 'comments="' + comments + '" ';
                        output += 'auto_play="' + auto_play + '" ';
                        output += 'width="' + width + '" ';
                        output += 'height="' + height + '" ';

                        output += ']';
                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                        tinyMCEPopup.close();

                    }
                }
                tinyMCEPopup.onInit.add( AddSoundcloud.init, AddSoundcloud );

            </script>
            <title>Add SoundCloud</title>

        </head>
        <body style="padding-top: 20px;"><div class="container">


                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddSoundcloud.insert( AddSoundcloud.e )">
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="url">URL</label>
                        <div class="col-sm-10">
                            <input type="text" id="url" name="url" value="http://">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="width">Width</label>
                        <div class="col-sm-10">
                            <input class="form-control" id="width" name="width" type="text" value="100%" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="height">Height</label>
                        <div class="col-sm-10">
                            <input class="form-control" id="height" name="height" type="text" value="118"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="comments">Comments</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="comments" name="comments">
                                <option value="true" selected="selected">True</option>
                                <option value="false">False</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="auto_play">Auto Play</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="auto_play" name="auto_play">
                                <option value="true">True</option>
                                <option value="false" selected="selected">False</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-2"></div>
                        <div class="col-sm-10">
                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                        </div>
                    </div>

                </form>

                <?php
            } elseif ( $page == 'leap_button' ) {
                ?>
                <script type="text/javascript">
                    var AddButton = {
                        e: '',
                        init: function ( e ) {
                            AddButton.e = e;
                            tinyMCEPopup.resizeToInnerSize();
                        },
                        insert: function createGalleryShortcode( e ) {

                            var align = jQuery( '#align' ).val();
                            var size = jQuery( '#size' ).val();
                            var type = jQuery( '#type' ).val();
                            var value = jQuery( '#value' ).val();
                            var link = jQuery( '#link' ).val();
                            var target = jQuery( '#target' ).val();
                            var customclass = jQuery( '#customclass' ).val();
                            var animationtype = jQuery( '#animationtype' ).val();
                            var animationspeed = jQuery( '#animationspeed' ).val();
                            var animationdelay = jQuery( '#animationdelay' ).val();
                            var animationoffset = jQuery( '#animationoffset' ).val();
                            var animationiteration = jQuery( '#animationiteration' ).val();


                            var output = '[leap_button ';

                            output += 'align="' + align + '" ';
                            output += 'size="' + size + '" ';
                            output += 'type="' + type + '" ';
                            output += 'link="' + link + '" ';
                            output += 'target="' + target + '" ';
                            output += 'class="' + customclass + '" ';


                            output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + value + '[/leap_button]';
                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                            tinyMCEPopup.close();

                        }
                    }
                    tinyMCEPopup.onInit.add( AddButton.init, AddButton );

                </script>
                <title>Add Button Shortcode</title>

                </head>
                <body style="padding-top: 20px;"><div class="container">


                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddButton.insert( AddButton.e )">

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="align">align</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="align" name="align">
                                        <option value="none" selected="selected">None</option>
                                        <option value="left">Left</option>
                                        <option value="center">Center</option>
                                        <option value="right">Right</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="size">Size</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="size" name="size">
                                        <option value="lg">Large</option>
                                        <option value="" selected="selected">Default</option>
                                        <option value="sm">Small</option>
                                        <option value="xs">Mini</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="type">Type</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="type" name="size">
                                        <option value="default-style" selected="selected">Default</option>
                                        <optgroup label="LEAP Buttons">
                                            <option value="orange">Orange</option>
                                            <option value="green1">Green 1</option>
                                            <option value="green2">Green 2</option>
                                            <option value="pink">Pink</option>
                                            <option value="purple">Purple</option>
                                            <option value="grey">Grey</option>
                                            <option value="white">White</option>
                                            <option value="red1">Red 1</option>
                                            <option value="red2">Red 2</option>
                                            <option value="blue1">Blue 1</option>
                                            <option value="blue2">Blue 2</option>
                                            <option value="gold">Gold</option>
                                            <option value="brown">Brown</option>
                                            <option value="black">Black</option>
                                        </optgroup>
                                        <optgroup label="Bootstrap Buttons">
                                            <option value="default">Default</option>
                                            <option value="primary">Primary</option>
                                            <option value="info">Info</option>
                                            <option value="success">Success</option>
                                            <option value="warning">Warning</option>
                                            <option value="danger">Danger</option>
                                            <option value="link">Link</option>
                                        </optgroup>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="value">Value</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="value" name="value" type="text" value="Button Content" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="link">Link</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="link" name="link" type="text" value="" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="target">Target</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="target" name="target">
                                        <option value="" selected="selected">Default</option>
                                        <option value="_blank">Blank</option>
                                        <option value="_parent">Parent</option>
                                        <option value="_self">Self</option>
                                        <option value="_top">Top</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="customclass">Custom Class</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="customclass" name="customclass" type="text" value=""/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                <div class="col-sm-10">
                                    <?php echo $animations; ?>
                                </div>
                            </div>


                            <div class="form-group" >
                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                </div>
                            </div>

                            <div class="form-group" >
                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                </div>
                            </div>

                            <div class="form-group" >
                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                </div>
                            </div>

                            <div class="form-group" >
                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                <div class="col-sm-10">
                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                </div>
                            </div>



                            <div class="form-group">
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10">
                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                </div>
                            </div>

                        </form>

                        <?php
                    } elseif ( $page == 'leap_dropcap' ) {
                        ?>
                        <script type="text/javascript">
                            var AddDropcap = {
                                e: '',
                                init: function ( e ) {
                                    AddDropcap.e = e;
                                    tinyMCEPopup.resizeToInnerSize();
                                },
                                insert: function createGalleryShortcode( e ) {

                                    var letter = jQuery( '#letter' ).val();
                                    var style = jQuery( '#style' ).val();


                                    var output = '[leap_dropcap ';

                                    output += 'style="' + style + '"]';
                                    output += letter;

                                    output += '[/leap_dropcap]';
                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                    tinyMCEPopup.close();

                                }
                            }
                            tinyMCEPopup.onInit.add( AddDropcap.init, AddDropcap );

                        </script>
                        <title>Add Dropcap Shortcode</title>

                        </head>
                        <body style="padding-top: 20px;"><div class="container">


                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddDropcap.insert( AddDropcap.e )">

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="letter">Insert Letter</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" id="letter" name="letter" type="text" value=""/>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                        <div class="col-sm-10">
                                            <select class="form-control" id="style" name="style">
                                                <option value="style-1" selected="selected">Style 1</option>
                                                <option value="style-2">Style 2</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-2"></div>
                                        <div class="col-sm-10">
                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                        </div>
                                    </div>

                                </form>

                                <?php
                            } elseif ( $page == 'leap_highlight' ) {
                                ?>
                                <script type="text/javascript">
                                    var AddHighlight = {
                                        e: '',
                                        init: function ( e ) {
                                            AddHighlight.e = e;
                                            tinyMCEPopup.resizeToInnerSize();
                                        },
                                        insert: function createGalleryShortcode( e ) {

                                            var style = jQuery( '#style' ).val();
                                            var text = jQuery( '#text' ).val();

                                            var output = '[leap_highlight ';

                                            output += 'style="' + style + '" ';

                                            output += ']' + text + '[/leap_highlight]';
                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                            tinyMCEPopup.close();

                                        }
                                    }
                                    tinyMCEPopup.onInit.add( AddHighlight.init, AddHighlight );

                                </script>
                                <title>Add Highlight Shortcode</title>

                                </head>
                                <body style="padding-top: 20px;"><div class="container">


                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddHighlight.insert( AddHighlight.e )">

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label" for="style">Style</label>
                                                <div class="col-sm-10">
                                                    <select class="form-control" id="style" name="style">
                                                        <option value="black">Black</option>
                                                        <option value="brown">Brown</option>
                                                        <option value="blue">Blue</option>
                                                        <option value="gold">Gold</option>
                                                        <option value="green">Green</option>
                                                        <option value="grey">Grey</option>
                                                        <option value="light-blue">light Blue</option>
                                                        <option value="light-green">Light Green</option>
                                                        <option value="light-red">Light Red</option>
                                                        <option value="orange" selected="selected">Orange</option>
                                                        <option value="pink">Pink</option>
                                                        <option value="purple">Purple</option>
                                                        <option value="red">Red</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-2 control-label" for="text">Text</label>
                                                <div class="col-sm-10">
                                                    <input class="form-control" id="text" name="text" type="text" value=""/>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="col-sm-2"></div>
                                                <div class="col-sm-10">
                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                </div>
                                            </div>

                                        </form>


                                        <?php
                                    } elseif ( $page == 'leap_google_font' ) {
                                        ?>
                                        <script type="text/javascript">
                                            var AddGooglefont = {
                                                e: '',
                                                init: function ( e ) {
                                                    AddGooglefont.e = e;
                                                    tinyMCEPopup.resizeToInnerSize();
                                                },
                                                insert: function createGalleryShortcode( e ) {

                                                    var family = jQuery( '#family' ).val();
                                                    var size = jQuery( '#size' ).val();
                                                    var lineheight = jQuery( '#lineheight' ).val();
                                                    var text = jQuery( '#text' ).val();

                                                    var output = '[leap_google_font ';

                                                    output += 'family="' + family + '" ';
                                                    output += 'size="' + size + '" ';
                                                    output += 'lineheight="' + lineheight + '" ';

                                                    output += ']' + text + '[/leap_google_font]';
                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                    tinyMCEPopup.close();

                                                }
                                            }
                                            tinyMCEPopup.onInit.add( AddGooglefont.init, AddGooglefont );

                                        </script>
                                        <title>Google Font</title>

                                        </head>
                                        <body style="padding-top: 20px;"><div class="container">


                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddGooglefont.insert( AddGooglefont.e )">

                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label" for="family">Font Family</label>
                                                        <div class="col-sm-10">
                                                            <input class="form-control" id="family" name="family" type="text" value=""/>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label" for="size">Font Size</label>
                                                        <div class="col-sm-10">
                                                            <input class="form-control" id="size" name="size" type="text" value="20px"/> Ex. 20px
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label" for="lineheight">Line Height</label>
                                                        <div class="col-sm-10">
                                                            <input class="form-control" id="lineheight" name="lineheight" type="text" value=""/> Ex. 20px
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label class="col-sm-2 control-label" for="text">Text</label>
                                                        <div class="col-sm-10">
                                                            <textarea class="form-control" id="text" name="text" value="" ></textarea>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <div class="col-sm-2"></div>
                                                        <div class="col-sm-10">
                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                        </div>
                                                    </div>

                                                </form>


                                                <?php
                                            } elseif ( $page == 'leap_quote' ) {
                                                ?>
                                                <script type="text/javascript">
                                                    var AddQuote = {
                                                        e: '',
                                                        init: function ( e ) {
                                                            AddQuote.e = e;
                                                            tinyMCEPopup.resizeToInnerSize();
                                                        },
                                                        insert: function createGalleryShortcode( e ) {

                                                            var style = jQuery( '#style' ).val();
                                                            var text = jQuery( '#text' ).val();
                                                            var bg_color = jQuery( '#bg_color' ).val();
                                                            var icon_size = jQuery( '#icon_size' ).val();
                                                            var icon_color = jQuery( '#icon_color' ).val();
                                                            var padding_right = jQuery( '#padding_right' ).val();
                                                            var padding_left = jQuery( '#padding_left' ).val();

                                                            var output = '[leap_quote ';

                                                            output += 'style="' + style + '" ';
                                                            output += 'bg_color="' + bg_color + '" ';
                                                            output += 'icon_size="' + icon_size + '" ';
                                                            output += 'icon_color="' + icon_color + '" ';
                                                            output += 'padding_right="' + padding_right + '" ';
                                                            output += 'padding_left="' + padding_left + '" ';

                                                            output += ']' + text + '[/leap_quote]';
                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                            tinyMCEPopup.close();

                                                        }
                                                    }
                                                    tinyMCEPopup.onInit.add( AddQuote.init, AddQuote );

                                                </script>
                                                <title>Add Quote Shortcode</title>

                                                </head>
                                                <body style="padding-top: 20px;"><div class="container">


                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddQuote.insert( AddQuote.e )">

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="style">Style</label>
                                                                <div class="col-sm-10">
                                                                    <select class="form-control" id="style" name="style">
                                                                        <option value="single-quotes" selected="selected">Single Quotes</option>
                                                                        <option value="single-quotes-bg">Single Quotes with Background</option>
                                                                        <option value="double-quotes">Double Quotes</option>
                                                                        <option value="double-quotes-bg">Double Quotes with Background</option>
                                                                    </select>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="bg_color">Background Color</label>
                                                                <div class="col-sm-10">
                                                                    <input class="form-control" id="bg_color" name="bg_color" type="text" value=""/>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="icon_size">Icon Size</label>
                                                                <div class="col-sm-10">
                                                                    <input class="form-control" id="icon_size" name="icon_size" type="text" value=""/>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="icon_color">Icon Color</label>
                                                                <div class="col-sm-10">
                                                                    <input class="form-control" id="icon_color" name="icon_color" type="text" value=""/>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="padding_right">Padding Right</label>
                                                                <div class="col-sm-10">
                                                                    <input class="form-control" id="padding_right" name="padding_right" type="text" value=""/>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="padding_left">Padding Left</label>
                                                                <div class="col-sm-10">
                                                                    <input class="form-control" id="padding_left" name="padding_left" type="text" value=""/>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-sm-2 control-label" for="text">Text</label>
                                                                <div class="col-sm-10">
                                                                    <textarea class="form-control" id="text" name="text" value="" ></textarea>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <div class="col-sm-2"></div>
                                                                <div class="col-sm-10">
                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                </div>
                                                            </div>

                                                        </form>


                                                        <?php
                                                    } elseif ( $page == 'leap_image_box' ) {
                                                        ?>
                                                        <script type="text/javascript">
                                                            var AddImagebox = {
                                                                e: '',
                                                                init: function ( e ) {
                                                                    AddImagebox.e = e;
                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                },
                                                                insert: function createGalleryShortcode( e ) {
                                                                    var layout = jQuery( '#layout' ).val();
                                                                    var centerbox = jQuery( '#centerbox' ).val();
                                                                    var image = jQuery( '#image' ).val();
                                                                    var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                    var hover_backgroundcolor = jQuery( '#hover_backgroundcolor' ).val();
                                                                    var title = jQuery( '#title' ).val();
                                                                    var font_family = jQuery( '#font_family' ).val();
                                                                    var font_size = jQuery( '#font_size' ).val();
                                                                    var line_height = jQuery( '#line_height' ).val();
                                                                    var titlecolor = jQuery( '#titlecolor' ).val();
                                                                    var hover_titlecolor = jQuery( '#hover_titlecolor' ).val();
                                                                    var text = jQuery( '#text' ).val();
                                                                    var hover_textcolor = jQuery( '#hover_textcolor' ).val();
                                                                    var link = jQuery( '#link' ).val();
                                                                    var linktext = jQuery( '#linktext' ).val();
                                                                    var linkcolor = jQuery( '#linkcolor' ).val();
                                                                    var hover_linkcolor = jQuery( '#hover_linkcolor' ).val();
                                                                    var linktarget = jQuery( '#linktarget' ).val();
                                                                    var image_effect = jQuery( '#image_effect' ).val();
                                                                    var animationtype = jQuery( '#animationtype' ).val();
                                                                    var animationspeed = jQuery( '#animationspeed' ).val();
                                                                    var animationdelay = jQuery( '#animationdelay' ).val();
                                                                    var animationoffset = jQuery( '#animationoffset' ).val();
                                                                    var animationiteration = jQuery( '#animationiteration' ).val();


                                                                    output = '[leap_image_box layout="' + layout + '" centerbox="' + centerbox + '" image="' + image + '" backgroundcolor="' + backgroundcolor + '" hover_backgroundcolor="' + hover_backgroundcolor + '" title="' + title + '" font_family="' + font_family + '" font_size="' + font_size + '" line_height="' + line_height + '" titlecolor="' + titlecolor + '" hover_titlecolor="' + hover_titlecolor + '" hover_textcolor="' + hover_textcolor + '" link="' + link + '"  linktext="' + linktext + '" linkcolor="' + linkcolor + '" hover_linkcolor="' + hover_linkcolor + '" linktarget="' + linktarget + '" image_effect="' + image_effect + '" animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + text + '[/leap_image_box]';

                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                    tinyMCEPopup.close();

                                                                }
                                                            }
                                                            tinyMCEPopup.onInit.add( AddImagebox.init, AddImagebox );

                                                        </script>
                                                        <title>Add Photo Box Shortcode</title>

                                                        </head>
                                                        <body style="padding-top: 20px;"><div class="container">


                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddImagebox.insert( AddImagebox.e )">

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="layout">Layout</label>
                                                                        <div class="col-sm-10">
                                                                            <select class="form-control" id="layout" name="layout">
                                                                                <option value="title-top" selected="selected">Title on top</option>
                                                                                <option value="image-top">Image on top</option>
                                                                                <option value="image-side">Image on side</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="centerbox">Center Box</label>
                                                                        <div class="col-sm-10">
                                                                            <select class="form-control" id="centerbox" name="centerbox">
                                                                                <option value="no" selected="selected">No</option>
                                                                                <option value="yes">Yes</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="backgroundcolor">Background color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="hover_backgroundcolor">Hover Background color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="hover_backgroundcolor" name="hover_backgroundcolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="image">Image</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="image" name="image" type="text" value=""/>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="title">Title</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="title" name="title" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="font_family">Font Family</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="font_family" name="font_family" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="font_size">Font Size</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="font_size" name="font_size" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="line_height">Line Height</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="line_height" name="line_height" type="text" value=""/>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="titlecolor">Title Color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="titlecolor" name="titlecolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="hover_titlecolor">Hover Title Color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="hover_titlecolor" name="hover_titlecolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="text">Text</label>
                                                                        <div class="col-sm-10">
                                                                            <textarea class="form-control" id="text" name="text" value="" ></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="hover_textcolor">Hover Text Color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="hover_textcolor" name="hover_textcolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="link">Link</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="link" name="link" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="linktext">Link Text</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="linktext" name="linktext" type="text" value=""/>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="linkcolor">Link color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="linkcolor" name="linkcolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="hover_linkcolor">Hover Link color</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="hover_linkcolor" name="hover_linkcolor" type="text" value=""/>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="linktarget">Target</label>
                                                                        <div class="col-sm-10">
                                                                            <select class="form-control" id="linktarget" name="linktarget">
                                                                                <option value="" selected="selected">Default</option>
                                                                                <option value="_blank">Blank</option>
                                                                                <option value="_parent">Parent</option>
                                                                                <option value="_self">Self</option>
                                                                                <option value="_top">Top</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="image_effect">Image Effect</label>
                                                                        <div class="col-sm-10">
                                                                            <select class="form-control" id="image_effect" name="image_effect">
                                                                                <option value="no" selected="selected">No</option>
                                                                                <option value="yes">Yes</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                        <div class="col-sm-10">
                                                                            <?php echo $animations; ?>
                                                                        </div>
                                                                    </div>


                                                                    <div class="form-group" >
                                                                        <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group" >
                                                                        <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group" >
                                                                        <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group" >
                                                                        <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                        <div class="col-sm-10">
                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                        </div>
                                                                    </div>


                                                                    <div class="form-group">
                                                                        <div class="col-sm-2"></div>
                                                                        <div class="col-sm-10">
                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                        </div>
                                                                    </div>

                                                                </form>


                                                                <?php
                                                            } elseif ( $page == 'leap_icon_box' ) {
                                                                ?>
                                                                <script type="text/javascript">
                                                                    var AddIconbox = {
                                                                        e: '',
                                                                        init: function ( e ) {
                                                                            AddIconbox.e = e;
                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                        },
                                                                        insert: function createGalleryShortcode( e ) {
                                                                            var layout = jQuery( '#layout' ).val();
                                                                            var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                            var iconimage = jQuery( '#iconimage' ).val();
                                                                            var iconimagewidth = jQuery( '#iconimagewidth' ).val();
                                                                            var iconimageheight = jQuery( '#iconimageheight' ).val();
                                                                            var title = jQuery( '#title' ).val();
                                                                            var titlecolor = jQuery( '#titlecolor' ).val();
                                                                            var text = jQuery( '#text' ).val();
                                                                            var circle = jQuery( '#circle' ).val();
                                                                            var circlecolor = jQuery( '#circlecolor' ).val();
                                                                            var circlebordercolor = jQuery( '#circlebordercolor' ).val();
                                                                            var icon = jQuery( '#icon' ).val();
                                                                            var iconcolor = jQuery( '#iconcolor' ).val();
                                                                            var link = jQuery( '#link' ).val();
                                                                            var linkcolor = jQuery( '#linkcolor' ).val();
                                                                            var linktext = jQuery( '#linktext' ).val();
                                                                            var linktarget = jQuery( '#linktarget' ).val();
                                                                            var animationtype = jQuery( '#animationtype' ).val();
                                                                            var animationspeed = jQuery( '#animationspeed' ).val();
                                                                            var animationdelay = jQuery( '#animationdelay' ).val();
                                                                            var animationoffset = jQuery( '#animationoffset' ).val();
                                                                            var animationiteration = jQuery( '#animationiteration' ).val();


                                                                            output = '[leap_icon_box layout="' + layout + '" backgroundcolor="' + backgroundcolor + '" iconimage="' + iconimage + '" iconimagewidth="' + iconimagewidth + '" iconimageheight="' + iconimageheight + '" title="' + title + '" titlecolor="' + titlecolor + '" circle="' + circle + '" circlecolor="' + circlecolor + '" circlebordercolor="' + circlebordercolor + '" icon="' + icon + '" iconcolor="' + iconcolor + '" link="' + link + '"  linkcolor="' + linkcolor + '" linktext="' + linktext + '" linktarget="' + linktarget + '" animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + text + '[/leap_icon_box]';

                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                            tinyMCEPopup.close();

                                                                        }
                                                                    }
                                                                    tinyMCEPopup.onInit.add( AddIconbox.init, AddIconbox );

                                                                </script>
                                                                <title>Add Icon Box Shortcode</title>

                                                                </head>
                                                                <body style="padding-top: 20px;"><div class="container">


                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddIconbox.insert( AddIconbox.e )">

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="layout">Layout</label>
                                                                                <div class="col-sm-10">
                                                                                    <select class="form-control" id="layout" name="layout">
                                                                                        <option value="icon-with-title" selected="selected">Icon with title</option>
                                                                                        <option value="icon-on-top">Icon on top</option>
                                                                                        <option value="icon-on-side">Icon on side</option>
                                                                                        <option value="icon-boxed">Icon boxed</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="backgroundcolor">Background color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="title" name="title" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="titlecolor">Title Color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="titlecolor" name="titlecolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="text">Text</label>
                                                                                <div class="col-sm-10">
                                                                                    <textarea class="form-control" id="text" name="text" value="" ></textarea>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="circle">Circle</label>
                                                                                <div class="col-sm-10">
                                                                                    <select class="form-control" id="circle" name="circle">
                                                                                        <option value="yes" selected="selected">Yes</option>
                                                                                        <option value="no">No</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="circlecolor">Circle color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="circlecolor" name="circlecolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="circlebordercolor">Circle border color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="circlebordercolor" name="circlebordercolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="icon">Icon</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="icon" name="icon" type="text" value=""/><br>Ex. fa-<b>chevron-right</b> <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/icons/">Icon List</a>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="iconcolor">Icon color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="iconcolor" name="iconcolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="iconimage">Icon Image</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="iconimage" name="iconimage" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="iconimagewidth">Icon Image Width</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="iconimagewidth" name="iconimagewidth" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="iconimageheight">Icon Image Height</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="iconimageheight" name="iconimageheight" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="link">Link</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="link" name="link" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="linkcolor">Link color</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="linkcolor" name="linkcolor" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="linktext">Link Text</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="linktext" name="linktext" type="text" value=""/>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="linktarget">Target</label>
                                                                                <div class="col-sm-10">
                                                                                    <select class="form-control" id="linktarget" name="linktarget">
                                                                                        <option value="" selected="selected">Default</option>
                                                                                        <option value="_blank">Blank</option>
                                                                                        <option value="_parent">Parent</option>
                                                                                        <option value="_self">Self</option>
                                                                                        <option value="_top">Top</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                <div class="col-sm-10">
                                                                                    <?php echo $animations; ?>
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group" >
                                                                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group" >
                                                                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group" >
                                                                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group" >
                                                                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group">
                                                                                <div class="col-sm-2"></div>
                                                                                <div class="col-sm-10">
                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                </div>
                                                                            </div>

                                                                        </form>


                                                                        <?php
                                                                    } elseif ( $page == 'leap_tagline' ) {
                                                                        ?>
                                                                        <script type="text/javascript">
                                                                            var AddTagline = {
                                                                                e: '',
                                                                                init: function ( e ) {
                                                                                    AddTagline.e = e;
                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                },
                                                                                insert: function createGalleryShortcode( e ) {

                                                                                    var style = jQuery( '#style' ).val();
                                                                                    var title = jQuery( '#title' ).val();
                                                                                    var description = jQuery( '#description' ).val();
                                                                                    var button = jQuery( '#button' ).val();
                                                                                    var link = jQuery( '#link' ).val();
                                                                                    var target = jQuery( '#target' ).val();
                                                                                    var centertext = jQuery( '#centertext' ).val();
                                                                                    var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                                    var titlecolor = jQuery( '#titlecolor' ).val();
                                                                                    var textcolor = jQuery( '#textcolor' ).val();
                                                                                    var bordersize = jQuery( '#bordersize' ).val();
                                                                                    var bordercolor = jQuery( '#bordercolor' ).val();
                                                                                    var borderstyle = jQuery( '#borderstyle' ).val();
                                                                                    var customclass = jQuery( '#customclass' ).val();
                                                                                    var animationtype = jQuery( '#animationtype' ).val();
                                                                                    var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                    var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                    var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                    var animationiteration = jQuery( '#animationiteration' ).val();


                                                                                    var output = '[leap_tagline_box ';

                                                                                    output += 'style="' + style + '" ';
                                                                                    output += 'title="' + title + '" ';
                                                                                    output += 'button="' + button + '" ';
                                                                                    output += 'link="' + link + '" ';
                                                                                    output += 'target="' + target + '" ';
                                                                                    output += 'centertext="' + centertext + '" ';
                                                                                    output += 'backgroundcolor="' + backgroundcolor + '" ';
                                                                                    output += 'titlecolor="' + titlecolor + '" ';
                                                                                    output += 'textcolor="' + textcolor + '" ';
                                                                                    output += 'bordersize="' + bordersize + '" ';
                                                                                    output += 'bordercolor="' + bordercolor + '" ';
                                                                                    output += 'borderstyle="' + borderstyle + '" ';
                                                                                    output += 'class="' + customclass + '" ';

                                                                                    output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + description + '[/leap_tagline_box]';
                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                    tinyMCEPopup.close();

                                                                                }
                                                                            }
                                                                            tinyMCEPopup.onInit.add( AddTagline.init, AddTagline );

                                                                        </script>
                                                                        <title>Add Tagline Shortcode</title>

                                                                        </head>
                                                                        <body style="padding-top: 20px;"><div class="container">


                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTagline.insert( AddTagline.e )">

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                        <div class="col-sm-10">
                                                                                            <select class="form-control" id="style" name="style">
                                                                                                <option value="tagline-1" selected="selected">Tagline 1</option>
                                                                                                <option value="tagline-2">Tagline 2</option>
                                                                                                <option value="tagline-3">Tagline 3</option>
                                                                                                <option value="tagline-4">Tagline 4</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                        <div class="col-sm-10">
                                                                                            <textarea class="form-control" id="title" name="title" value="" ></textarea>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="description">Description</label>
                                                                                        <div class="col-sm-10">
                                                                                            <textarea class="form-control" id="description" name="description" value="" ></textarea>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="button">Button</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="button" name="button" type="text" value="" placeholder="Button Content" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="link">Link</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="link" name="link" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="target">Target</label>
                                                                                        <div class="col-sm-10">
                                                                                            <select class="form-control" id="target" name="target">
                                                                                                <option value="" selected="selected">Default</option>
                                                                                                <option value="_blank">Blank</option>
                                                                                                <option value="_parent">Parent</option>
                                                                                                <option value="_self">Self</option>
                                                                                                <option value="_top">Top</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="centertext">Center Text</label>
                                                                                        <div class="col-sm-10">
                                                                                            <select class="form-control" id="centertext" name="target">
                                                                                                <option value="yes">Yes</option>
                                                                                                <option value="no" selected="selected">No</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="backgroundcolor">Background Color</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="titlecolor">Title Color</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="titlecolor" name="titlecolor" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="textcolor">Text Color</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="textcolor" name="textcolor" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="bordersize">Border Size</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="bordersize" name="bordersize" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="bordercolor">Border Color</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="bordercolor" name="bordercolor" type="text" value="" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group" >
                                                                                        <label class="col-sm-2 control-label" for="borderstyle">Border Style</label>
                                                                                        <div class="col-sm-10">
                                                                                            <select name="borderstyle" id="borderstyle" class="form-control">
                                                                                                <option value="solid">Solid</option>
                                                                                                <option value="dashed">Dashed</option>
                                                                                                <option value="dotted">Dotted</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="customclass">Custom Class</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="customclass" name="customclass" type="text" value=""/>
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                        <div class="col-sm-10">
                                                                                            <?php echo $animations; ?>
                                                                                        </div>
                                                                                    </div>


                                                                                    <div class="form-group" >
                                                                                        <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group" >
                                                                                        <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group" >
                                                                                        <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group" >
                                                                                        <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                        </div>
                                                                                    </div>

                                                                                    <div class="form-group">
                                                                                        <div class="col-sm-2"></div>
                                                                                        <div class="col-sm-10">
                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                        </div>
                                                                                    </div>

                                                                                </form>


                                                                                <?php
                                                                            } elseif ( $page == 'leap_onehalf' ) {
                                                                                ?>
                                                                                <script type="text/javascript">
                                                                                    var AddOnehalf = {
                                                                                        e: '',
                                                                                        init: function ( e ) {
                                                                                            AddOnehalf.e = e;
                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                        },
                                                                                        insert: function createGalleryShortcode( e ) {

                                                                                            var content = jQuery( '#content' ).val();
                                                                                            var last = jQuery( '#last' ).val();
                                                                                            var margintop = jQuery( '#margintop' ).val();
                                                                                            var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                            var animationtype = jQuery( '#animationtype' ).val();
                                                                                            var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                            var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                            var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                            var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                            var output = '[leap_one_half ';

                                                                                            output += 'last="' + last + '" ';
                                                                                            output += 'margintop="' + margintop + '" ';
                                                                                            output += 'marginbottom="' + marginbottom + '" ';

                                                                                            output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_one_half]';
                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                            tinyMCEPopup.close();

                                                                                        }
                                                                                    }
                                                                                    tinyMCEPopup.onInit.add( AddOnehalf.init, AddOnehalf );

                                                                                </script>
                                                                                <title>Add One Half Shortcode</title>

                                                                                </head>
                                                                                <body style="padding-top: 20px;"><div class="container">


                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddOnehalf.insert( AddOnehalf.e )">

                                                                                            <div class="form-group">
                                                                                                <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group">
                                                                                                <label class="col-sm-2 control-label" for="last">Last</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <select class="form-control" id="last" name="last">
                                                                                                        <option value="yes">Yes</option>
                                                                                                        <option value="no" selected="selected">No</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group">
                                                                                                <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="margintop" name="margintop" type="text" value=""/> Ex. 10px
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group">
                                                                                                <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="marginbottom" name="marginbottom" type="text" value=""/> Ex. 10px
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group">
                                                                                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <?php echo $animations; ?>
                                                                                                </div>
                                                                                            </div>


                                                                                            <div class="form-group" >
                                                                                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group" >
                                                                                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group" >
                                                                                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group" >
                                                                                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                </div>
                                                                                            </div>

                                                                                            <div class="form-group">
                                                                                                <div class="col-sm-2"></div>
                                                                                                <div class="col-sm-10">
                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                </div>
                                                                                            </div>

                                                                                        </form>


                                                                                        <?php
                                                                                    } elseif ( $page == 'leap_onethird' ) {
                                                                                        ?>
                                                                                        <script type="text/javascript">
                                                                                            var AddOnethird = {
                                                                                                e: '',
                                                                                                init: function ( e ) {
                                                                                                    AddOnethird.e = e;
                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                },
                                                                                                insert: function createGalleryShortcode( e ) {

                                                                                                    var content = jQuery( '#content' ).val();
                                                                                                    var last = jQuery( '#last' ).val();
                                                                                                    var margintop = jQuery( '#margintop' ).val();
                                                                                                    var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                                    var animationtype = jQuery( '#animationtype' ).val();
                                                                                                    var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                    var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                    var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                    var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                    var output = '[leap_one_third ';

                                                                                                    output += 'last="' + last + '" ';
                                                                                                    output += 'margintop="' + margintop + '" ';
                                                                                                    output += 'marginbottom="' + marginbottom + '" ';

                                                                                                    output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_one_third]';
                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                    tinyMCEPopup.close();

                                                                                                }
                                                                                            }
                                                                                            tinyMCEPopup.onInit.add( AddOnethird.init, AddOnethird );

                                                                                        </script>
                                                                                        <title>Add One Third Shortcode</title>

                                                                                        </head>
                                                                                        <body style="padding-top: 20px;"><div class="container">


                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddOnethird.insert( AddOnethird.e )">

                                                                                                    <div class="form-group">
                                                                                                        <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group">
                                                                                                        <label class="col-sm-2 control-label" for="last">Last</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <select class="form-control" id="last" name="last">
                                                                                                                <option value="yes">Yes</option>
                                                                                                                <option value="no" selected="selected">No</option>
                                                                                                            </select>
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group">
                                                                                                        <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="margintop" name="margintop" type="text" value=""/> Ex. 10px
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group">
                                                                                                        <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="marginbottom" name="marginbottom" type="text" value=""/> Ex. 10px
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group">
                                                                                                        <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <?php echo $animations; ?>
                                                                                                        </div>
                                                                                                    </div>


                                                                                                    <div class="form-group" >
                                                                                                        <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group" >
                                                                                                        <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group" >
                                                                                                        <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group" >
                                                                                                        <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                        </div>
                                                                                                    </div>

                                                                                                    <div class="form-group">
                                                                                                        <div class="col-sm-2"></div>
                                                                                                        <div class="col-sm-10">
                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                        </div>
                                                                                                    </div>

                                                                                                </form>


                                                                                                <?php
                                                                                            } elseif ( $page == 'leap_twothird' ) {
                                                                                                ?>
                                                                                                <script type="text/javascript">
                                                                                                    var AddTwothird = {
                                                                                                        e: '',
                                                                                                        init: function ( e ) {
                                                                                                            AddTwothird.e = e;
                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                        },
                                                                                                        insert: function createGalleryShortcode( e ) {

                                                                                                            var content = jQuery( '#content' ).val();
                                                                                                            var last = jQuery( '#last' ).val();
                                                                                                            var margintop = jQuery( '#margintop' ).val();
                                                                                                            var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                                            var animationtype = jQuery( '#animationtype' ).val();
                                                                                                            var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                            var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                            var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                            var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                            var output = '[leap_two_third ';

                                                                                                            output += 'last="' + last + '" ';
                                                                                                            output += 'margintop="' + margintop + '" ';
                                                                                                            output += 'marginbottom="' + marginbottom + '" ';

                                                                                                            output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_two_third]';
                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                            tinyMCEPopup.close();

                                                                                                        }
                                                                                                    }
                                                                                                    tinyMCEPopup.onInit.add( AddTwothird.init, AddTwothird );

                                                                                                </script>
                                                                                                <title>Add Two Third Shortcode</title>

                                                                                                </head>
                                                                                                <body style="padding-top: 20px;"><div class="container">


                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTwothird.insert( AddTwothird.e )">

                                                                                                            <div class="form-group">
                                                                                                                <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group">
                                                                                                                <label class="col-sm-2 control-label" for="last">Last</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <select class="form-control" id="last" name="last">
                                                                                                                        <option value="yes">Yes</option>
                                                                                                                        <option value="no" selected="selected">No</option>
                                                                                                                    </select>
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group">
                                                                                                                <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="margintop" name="margintop" type="text" value=""/> Ex. 10px
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group">
                                                                                                                <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="marginbottom" name="marginbottom" type="text" value=""/> Ex. 10px
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group">
                                                                                                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <?php echo $animations; ?>
                                                                                                                </div>
                                                                                                            </div>


                                                                                                            <div class="form-group" >
                                                                                                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group" >
                                                                                                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group" >
                                                                                                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group" >
                                                                                                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                </div>
                                                                                                            </div>

                                                                                                            <div class="form-group">
                                                                                                                <div class="col-sm-2"></div>
                                                                                                                <div class="col-sm-10">
                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                </div>
                                                                                                            </div>

                                                                                                        </form>

                                                                                                        <?php
                                                                                                    } elseif ( $page == 'leap_onefourth' ) {
                                                                                                        ?>
                                                                                                        <script type="text/javascript">
                                                                                                            var AddOnefourth = {
                                                                                                                e: '',
                                                                                                                init: function ( e ) {
                                                                                                                    AddOnefourth.e = e;
                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                },
                                                                                                                insert: function createGalleryShortcode( e ) {

                                                                                                                    var content = jQuery( '#content' ).val();
                                                                                                                    var last = jQuery( '#last' ).val();
                                                                                                                    var margintop = jQuery( '#margintop' ).val();
                                                                                                                    var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                                                    var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                    var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                    var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                    var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                    var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                    var output = '[leap_one_fourth ';

                                                                                                                    output += 'last="' + last + '" ';
                                                                                                                    output += 'margintop="' + margintop + '" ';
                                                                                                                    output += 'marginbottom="' + marginbottom + '" ';

                                                                                                                    output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_one_fourth]';
                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                    tinyMCEPopup.close();

                                                                                                                }
                                                                                                            }
                                                                                                            tinyMCEPopup.onInit.add( AddOnefourth.init, AddOnefourth );

                                                                                                        </script>
                                                                                                        <title>Add One Fourth Shortcode</title>

                                                                                                        </head>
                                                                                                        <body style="padding-top: 20px;"><div class="container">


                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddOnefourth.insert( AddOnefourth.e )">

                                                                                                                    <div class="form-group">
                                                                                                                        <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group">
                                                                                                                        <label class="col-sm-2 control-label" for="last">Last</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <select class="form-control" id="last" name="last">
                                                                                                                                <option value="yes">Yes</option>
                                                                                                                                <option value="no" selected="selected">No</option>
                                                                                                                            </select>
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group">
                                                                                                                        <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="margintop" name="margintop" type="text" value=""/> Ex. 10px
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group">
                                                                                                                        <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="marginbottom" name="marginbottom" type="text" value=""/> Ex. 10px
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group">
                                                                                                                        <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <?php echo $animations; ?>
                                                                                                                        </div>
                                                                                                                    </div>


                                                                                                                    <div class="form-group" >
                                                                                                                        <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group" >
                                                                                                                        <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group" >
                                                                                                                        <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group" >
                                                                                                                        <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                    <div class="form-group">
                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                        <div class="col-sm-10">
                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                        </div>
                                                                                                                    </div>

                                                                                                                </form>


                                                                                                                <?php
                                                                                                            } elseif ( $page == 'leap_threefourth' ) {
                                                                                                                ?>
                                                                                                                <script type="text/javascript">
                                                                                                                    var AddThreefourth = {
                                                                                                                        e: '',
                                                                                                                        init: function ( e ) {
                                                                                                                            AddThreefourth.e = e;
                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                        },
                                                                                                                        insert: function createGalleryShortcode( e ) {

                                                                                                                            var content = jQuery( '#content' ).val();
                                                                                                                            var last = jQuery( '#last' ).val();
                                                                                                                            var margintop = jQuery( '#margintop' ).val();
                                                                                                                            var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                                                            var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                            var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                            var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                            var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                            var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                            var output = '[leap_three_fourth ';

                                                                                                                            output += 'last="' + last + '" ';
                                                                                                                            output += 'margintop="' + margintop + '" ';
                                                                                                                            output += 'marginbottom="' + marginbottom + '" ';

                                                                                                                            output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_three_fourth]';
                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                            tinyMCEPopup.close();

                                                                                                                        }
                                                                                                                    }
                                                                                                                    tinyMCEPopup.onInit.add( AddThreefourth.init, AddThreefourth );

                                                                                                                </script>
                                                                                                                <title>Add Three Fourth Shortcode</title>

                                                                                                                </head>
                                                                                                                <body style="padding-top: 20px;"><div class="container">


                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddThreefourth.insert( AddThreefourth.e )">

                                                                                                                            <div class="form-group">
                                                                                                                                <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group">
                                                                                                                                <label class="col-sm-2 control-label" for="last">Last</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <select class="form-control" id="last" name="last">
                                                                                                                                        <option value="yes">Yes</option>
                                                                                                                                        <option value="no" selected="selected">No</option>
                                                                                                                                    </select>
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group">
                                                                                                                                <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="margintop" name="margintop" type="text" value=""/>
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group">
                                                                                                                                <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="marginbottom" name="marginbottom" type="text" value=""/>
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group">
                                                                                                                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <?php echo $animations; ?>
                                                                                                                                </div>
                                                                                                                            </div>


                                                                                                                            <div class="form-group" >
                                                                                                                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group" >
                                                                                                                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group" >
                                                                                                                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group" >
                                                                                                                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                            <div class="form-group">
                                                                                                                                <div class="col-sm-2"></div>
                                                                                                                                <div class="col-sm-10">
                                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                </div>
                                                                                                                            </div>

                                                                                                                        </form>


                                                                                                                        <?php
                                                                                                                    } elseif ( $page == 'leap_toggle' ) {
                                                                                                                        ?>
                                                                                                                        <script type="text/javascript">
                                                                                                                            var AddToggle = {
                                                                                                                                e: '',
                                                                                                                                init: function ( e ) {
                                                                                                                                    AddToggle.e = e;
                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                },
                                                                                                                                insert: function createGalleryShortcode( e ) {

                                                                                                                                    var title = jQuery( '#title' ).val();
                                                                                                                                    var open = jQuery( '#open' ).val();
                                                                                                                                    var style = jQuery( '#style' ).val();
                                                                                                                                    var content = jQuery( '#content' ).val();

                                                                                                                                    var output = '[leap_toggle ';

                                                                                                                                    output += 'title="' + title + '" ';

                                                                                                                                    output += 'open="' + open + '" ';

                                                                                                                                    output += 'style="' + style + '" ';

                                                                                                                                    output += ']' + content + '[/leap_toggle]';
                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                }
                                                                                                                            }
                                                                                                                            tinyMCEPopup.onInit.add( AddToggle.init, AddToggle );

                                                                                                                        </script>
                                                                                                                        <title>Add Toggle Shortcode</title>

                                                                                                                        </head>
                                                                                                                        <body style="padding-top: 20px;"><div class="container">


                                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddToggle.insert( AddToggle.e )">

                                                                                                                                    <div class="form-group">
                                                                                                                                        <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                                                                        <div class="col-sm-10">
                                                                                                                                            <input class="form-control" id="title" name="title" type="text" value=""/>
                                                                                                                                        </div>
                                                                                                                                    </div>

                                                                                                                                    <div class="form-group">
                                                                                                                                        <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                                        <div class="col-sm-10">
                                                                                                                                            <textarea class="form-control" id="content" name="content" value=""></textarea>
                                                                                                                                        </div>
                                                                                                                                    </div>

                                                                                                                                    <div class="form-group">
                                                                                                                                        <label class="col-sm-2 control-label" for="open">Open</label>
                                                                                                                                        <div class="col-sm-10">
                                                                                                                                            <select class="form-control" id="open" name="open">
                                                                                                                                                <option value="yes">Yes</option>
                                                                                                                                                <option value="no" selected="selected">No</option>
                                                                                                                                            </select>
                                                                                                                                        </div>
                                                                                                                                    </div>

                                                                                                                                    <div class="form-group">
                                                                                                                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                        <div class="col-sm-10">
                                                                                                                                            <select class="form-control" id="style" name="style">
                                                                                                                                                <option value="style-1" selected="selected">Style 1</option>
                                                                                                                                                <option value="style-2">Style 2</option>
                                                                                                                                                <option value="style-3">Style 3</option>
                                                                                                                                            </select>
                                                                                                                                        </div>
                                                                                                                                    </div>

                                                                                                                                    <div class="form-group">
                                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                                        <div class="col-sm-10">
                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                        </div>
                                                                                                                                    </div>

                                                                                                                                </form>


                                                                                                                                <?php
                                                                                                                            } elseif ( $page == 'leap_accordion' ) {
                                                                                                                                ?>
                                                                                                                                <script type="text/javascript">
                                                                                                                                    var AddAccordion = {
                                                                                                                                        e: '',
                                                                                                                                        init: function ( e ) {
                                                                                                                                            AddAccordion.e = e;
                                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                                        },
                                                                                                                                        insert: function createGalleryShortcode( e ) {

                                                                                                                                            var style = jQuery( '#style' ).val();
                                                                                                                                            var title_color = jQuery( '#title_color' ).val();
                                                                                                                                            var title_hover_color = jQuery( '#title_hover_color' ).val();
                                                                                                                                            var title_bg = jQuery( '#title_bg' ).val();
                                                                                                                                            var title_hover_bg = jQuery( '#title_hover_bg' ).val();
                                                                                                                                            var content_bg = jQuery( '#content_bg' ).val();
                                                                                                                                            var itemNumbers = jQuery( '#itemNumbers' ).val();

                                                                                                                                            var output = '[leap_accordion ';

                                                                                                                                            output += 'style="' + style + '" ';
                                                                                                                                            output += 'title_color="' + title_color + '" ';
                                                                                                                                            output += 'title_hover_color="' + title_hover_color + '" ';
                                                                                                                                            output += 'title_bg="' + title_bg + '" ';
                                                                                                                                            output += 'title_hover_bg="' + title_hover_bg + '" ';
                                                                                                                                            output += 'content_bg="' + content_bg + '" ';

                                                                                                                                            output += ']';

                                                                                                                                            for ( var i = 1; i <= itemNumbers; i++ ) {
                                                                                                                                                output += '[leap_accordion_item title="Title ' + i + '"]Content goes here...[/leap_accordion_item]';
                                                                                                                                            }

                                                                                                                                            output += '[/leap_accordion]';
                                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                            tinyMCEPopup.close();

                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    tinyMCEPopup.onInit.add( AddAccordion.init, AddAccordion );

                                                                                                                                </script>
                                                                                                                                <title>Add Accordion Shortcode</title>

                                                                                                                                </head>
                                                                                                                                <body style="padding-top: 20px;"><div class="container">


                                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddAccordion.insert( AddAccordion.e )">

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="itemNumbers">Number of Items</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="itemNumbers" name="itemNumbers" type="number" value="5" min="1" required />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <select class="form-control" id="style" name="style">
                                                                                                                                                        <option value="style-1" selected="selected">Style 1</option>
                                                                                                                                                        <option value="style-2">Style 2</option>
                                                                                                                                                        <option value="style-3">Style 3</option>
                                                                                                                                                    </select>
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="title_color">Title Text Color</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="title_color" name="title_color" type="text" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="title_hover_color">Title Text Hover Color</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="title_hover_color" name="title_hover_color" type="text" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="title_bg">Title Background Color</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="title_bg" name="title_bg" type="text" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="title_hover_bg">Title Background Hover Color</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="title_hover_bg" name="title_hover_bg" type="text" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <label class="col-sm-2 control-label" for="content_bg">Content Background Color</label>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="form-control" id="content_bg" name="content_bg" type="text" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                            <div class="form-group">
                                                                                                                                                <div class="col-sm-2"></div>
                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                </div>
                                                                                                                                            </div>

                                                                                                                                        </form>


                                                                                                                                        <?php
                                                                                                                                    } elseif ( $page == 'leap_recentposts' ) {
                                                                                                                                        ?>
                                                                                                                                        <script type="text/javascript">
                                                                                                                                            var AddRecentposts = {
                                                                                                                                                e: '',
                                                                                                                                                init: function ( e ) {
                                                                                                                                                    AddRecentposts.e = e;
                                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                },
                                                                                                                                                insert: function createGalleryShortcode( e ) {

                                                                                                                                                    var style = jQuery( '#style' ).val();
                                                                                                                                                    var posts = jQuery( '#posts' ).val();
                                                                                                                                                    var columns = jQuery( '#columns' ).val();
                                                                                                                                                    var cats = jQuery( '#cats' ).val();
                                                                                                                                                    var readmore = jQuery( '#readmore' ).val();
                                                                                                                                                    var excerptlength = jQuery( '#excerptlength' ).val();
                                                                                                                                                    var titlecolor = jQuery( '#titlecolor' ).val();
                                                                                                                                                    var metacolor = jQuery( '#metacolor' ).val();
                                                                                                                                                    var textcolor = jQuery( '#textcolor' ).val();
                                                                                                                                                    var morecolor = jQuery( '#morecolor' ).val();
                                                                                                                                                    var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                                                    var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                                                    var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                                                    var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                                                    var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                                                    var output = '[leap_recentposts ';

                                                                                                                                                    output += 'style="' + style + '" ';
                                                                                                                                                    output += 'posts="' + posts + '" ';
                                                                                                                                                    output += 'columns="' + columns + '" ';
                                                                                                                                                    output += 'cats="' + cats + '" ';
                                                                                                                                                    output += 'readmore="' + readmore + '" ';
                                                                                                                                                    output += 'excerptlength="' + excerptlength + '" ';
                                                                                                                                                    output += 'titlecolor="' + titlecolor + '" ';
                                                                                                                                                    output += 'metacolor="' + metacolor + '" ';
                                                                                                                                                    output += 'textcolor="' + textcolor + '" ';
                                                                                                                                                    output += 'morecolor="' + morecolor + '" ';

                                                                                                                                                    output += ' animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]';

                                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            tinyMCEPopup.onInit.add( AddRecentposts.init, AddRecentposts );

                                                                                                                                        </script>
                                                                                                                                        <title>Add Recent Posts Shortcode</title>

                                                                                                                                        </head>
                                                                                                                                        <body style="padding-top: 20px;"><div class="container">


                                                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddRecentposts.insert( AddRecentposts.e )">

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <select class="form-control" id="style" name="style">
                                                                                                                                                                <option value="style-1" selected="selected">Style 1</option>
                                                                                                                                                                <option value="style-2">Style 2</option>
                                                                                                                                                                <option value="style-3">Style 3</option>
                                                                                                                                                                <option value="style-4">Style 4</option>
                                                                                                                                                            </select>
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="posts">Number of Posts</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="posts" name="posts" type="number" value="5" min="1" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="columns">Columns</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="columns" name="columns" type="number" value="3" min="1" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="cats">Categories Slugs</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="cats" name="cats" type="text" value="" /><br />
                                                                                                                                                            Separated by comma
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="readmore">Display Read More</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <select class="form-control" id="readmore" name="readmore">
                                                                                                                                                                <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                <option value="no">No</option>
                                                                                                                                                            </select>
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="excerptlength">Excerpt Length</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="excerptlength" name="excerptlength" type="text" value="" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="titlecolor">Title Color</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="titlecolor" name="titlecolor" type="text" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="metacolor">Meta Color</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="metacolor" name="metacolor" type="text" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="textcolor">Text Color</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="textcolor" name="textcolor" type="text" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="morecolor">Read More Color</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="morecolor" name="morecolor" type="text" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <?php echo $animations; ?>
                                                                                                                                                        </div>
                                                                                                                                                    </div>


                                                                                                                                                    <div class="form-group" >
                                                                                                                                                        <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group" >
                                                                                                                                                        <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group" >
                                                                                                                                                        <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group" >
                                                                                                                                                        <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                    <div class="form-group">
                                                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                        </div>
                                                                                                                                                    </div>

                                                                                                                                                </form>

                                                                                                                                                <?php
                                                                                                                                            } elseif ( $page == 'leap_iframe' ) {
                                                                                                                                                ?>
                                                                                                                                                <script type="text/javascript">
                                                                                                                                                    var AddIframe = {
                                                                                                                                                        e: '',
                                                                                                                                                        init: function ( e ) {
                                                                                                                                                            AddIframe.e = e;
                                                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                        },
                                                                                                                                                        insert: function createGalleryShortcode( e ) {

                                                                                                                                                            var width = jQuery( '#width' ).val();
                                                                                                                                                            var height = jQuery( '#height' ).val();
                                                                                                                                                            var scrolling = jQuery( '#scrolling' ).val();
                                                                                                                                                            var url = jQuery( '#url' ).val();

                                                                                                                                                            var output = '[leap_iframe ';

                                                                                                                                                            output += 'width="' + width + '" ';
                                                                                                                                                            output += 'height="' + height + '" ';
                                                                                                                                                            output += 'scrolling="' + scrolling + '" ';
                                                                                                                                                            output += 'url="' + url + '" ';

                                                                                                                                                            output += ']';

                                                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                            tinyMCEPopup.close();

                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                    tinyMCEPopup.onInit.add( AddIframe.init, AddIframe );

                                                                                                                                                </script>
                                                                                                                                                <title>Add Iframe Shortcode</title>

                                                                                                                                                </head>
                                                                                                                                                <body style="padding-top: 20px;"><div class="container">


                                                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddIframe.insert( AddIframe.e )">

                                                                                                                                                            <div class="form-group">
                                                                                                                                                                <label class="col-sm-2 control-label" for="width">Width</label>
                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                    <input class="form-control" id="width" name="width" type="number" value="500" min="1" required />
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                            <div class="form-group">
                                                                                                                                                                <label class="col-sm-2 control-label" for="height">Height</label>
                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                    <input class="form-control" id="height" name="height" type="text" value="300" />
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                            <div class="form-group">
                                                                                                                                                                <label class="col-sm-2 control-label" for="scrolling">scrolling</label>
                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                    <select class="form-control" id="scrolling" name="scrolling">
                                                                                                                                                                        <option value="no" selected="selected">No</option>
                                                                                                                                                                        <option value="yes">Yes</option>
                                                                                                                                                                    </select>
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                            <div class="form-group">
                                                                                                                                                                <label class="col-sm-2 control-label" for="url">URL</label>
                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                    <input class="form-control" id="url" name="url" type="text" value="" />
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                            <div class="form-group">
                                                                                                                                                                <div class="col-sm-2"></div>
                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                        </form>

                                                                                                                                                        <?php
                                                                                                                                                    } elseif ( $page == 'leap_lightbox' ) {
                                                                                                                                                        ?>
                                                                                                                                                        <script type="text/javascript">
                                                                                                                                                            var AddLightbox = {
                                                                                                                                                                e: '',
                                                                                                                                                                init: function ( e ) {
                                                                                                                                                                    AddLightbox.e = e;
                                                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                },
                                                                                                                                                                insert: function createGalleryShortcode( e ) {

                                                                                                                                                                    var url = jQuery( '#url' ).val();
                                                                                                                                                                    var title = jQuery( '#title' ).val();
                                                                                                                                                                    var content = jQuery( '#content' ).val();

                                                                                                                                                                    var output = '[leap_lightbox ';

                                                                                                                                                                    if ( url ) {
                                                                                                                                                                        output += 'url="' + url + '" ';
                                                                                                                                                                    }

                                                                                                                                                                    if ( title ) {
                                                                                                                                                                        output += 'title="' + title + '" ';
                                                                                                                                                                    }

                                                                                                                                                                    output += ']' + content + '[/leap_lightbox]';

                                                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            tinyMCEPopup.onInit.add( AddLightbox.init, AddLightbox );

                                                                                                                                                        </script>
                                                                                                                                                        <title>Add Lightbox Shortcode</title>

                                                                                                                                                        </head>
                                                                                                                                                        <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddLightbox.insert( AddLightbox.e )">

                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                        <label class="col-sm-2 control-label" for="url">Full Image or Youtube / Vimeo Video URL : </label>
                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                            <input class="form-control" id="url" name="url" type="url" value="" required />
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>

                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                        <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                            <input class="form-control" id="title" name="title" type="text" value="" />
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>

                                                                                                                                                                    <div class="form-group" >
                                                                                                                                                                        <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                            <input class="form-control" id="content" name="content" type="text" value="" required />
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>

                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>

                                                                                                                                                                </form>

                                                                                                                                                                <?php
                                                                                                                                                            } elseif ( $page == 'leap_title' ) {
                                                                                                                                                                ?>
                                                                                                                                                                <script type="text/javascript">
                                                                                                                                                                    var AddTitle = {
                                                                                                                                                                        e: '',
                                                                                                                                                                        init: function ( e ) {
                                                                                                                                                                            AddTitle.e = e;
                                                                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                        },
                                                                                                                                                                        insert: function createGalleryShortcode( e ) {
                                                                                                                                                                            var title = jQuery( '#title' ).val();
                                                                                                                                                                            var heading = jQuery( '#heading' ).val();
                                                                                                                                                                            var color = jQuery( '#color' ).val();
                                                                                                                                                                            var style = jQuery( '#style' ).val();
                                                                                                                                                                            var strip = jQuery( '#strip' ).val();
                                                                                                                                                                            var center = jQuery( '#center' ).val();
                                                                                                                                                                            var font_family = jQuery( '#font_family' ).val();
                                                                                                                                                                            var font_size = jQuery( '#font_size' ).val();
                                                                                                                                                                            var line_height = jQuery( '#line_height' ).val();
                                                                                                                                                                            var icon = jQuery( '#icon' ).val();                               
                                                                                                                                                                            var margin_top = jQuery( '#margin_top' ).val();
                                                                                                                                                                            var margin_bottom = jQuery( '#margin_bottom' ).val();
                                                                                                                                                                            var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                                                                            var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                                                                            var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                                                                            var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                                                                            var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                                                                            var output = '[leap_title ';
output
                                                                                                                                                                            output += 'heading="' + heading + '" ';
                                                                                                                                                                            output += 'color="' + color + '" ';
                                                                                                                                                                            output += 'style="' + style + '" ';
                                                                                                                                                                            output += 'strip="' + strip + '" ';
                                                                                                                                                                            output += 'center="' + center + '" ';
                                                                                                                                                                            output += 'font_family="' + font_family + '" ';
                                                                                                                                                                            output += 'font_size="' + font_size + '" ';
                                                                                                                                                                            output += 'line_height="' + line_height + '" ';
                                                                                                                                                                            output += 'icon="' + icon + '" ';
                                                                                                                                                                            output += 'margin_top="' + margin_top + '" ';
                                                                                                                                                                            output += 'margin_bottom="' + margin_bottom + '" ';

                                                                                                                                                                            output += 'animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '"]' + title + '[/leap_title]';

                                                                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                            tinyMCEPopup.close();

                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                    tinyMCEPopup.onInit.add( AddTitle.init, AddTitle );

                                                                                                                                                                </script>
                                                                                                                                                                <title>Add Title Shortcode</title>

                                                                                                                                                                </head>
                                                                                                                                                                <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTitle.insert( AddTitle.e )">

                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="title" name="title" type="text" value="Title goes here" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <label class="col-sm-2 control-label" for="heading">Heading</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <select class="form-control" id="heading" name="heading">
                                                                                                                                                                                        <option value="h1">H1</option>
                                                                                                                                                                                        <option value="h2" selected="selected">H2</option>
                                                                                                                                                                                        <option value="h3">H3</option>
                                                                                                                                                                                        <option value="h4">H4</option>
                                                                                                                                                                                        <option value="h5">H5</option>
                                                                                                                                                                                        <option value="h6">H6</option>
                                                                                                                                                                                    </select>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="color">Color</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="color" name="color" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            
                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <select class="form-control" id="style" name="style">
                                                                                                                                                                                        <option value="style1">Style1</option>
                                                                                                                                                                                        <option value="style2">Style2</option>
                                                                                                                                                                                        <option value="style3">Style3</option>
                                                                                                                                                                                        <option value="style4">Style4</option>
                                                                                                                                                                                        <option value="style5">Style5</option>
                                                                                                                                                                                        <option value="style6">Style6</option>
                                                                                                                                                                                        <option value="style7">Style7</option>
                                                                                                                                                                                    </select>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <label class="col-sm-2 control-label" for="strip">Strip</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <select class="form-control" id="strip" name="strip">
                                                                                                                                                                                        <option value="no">No</option>
                                                                                                                                                                                        <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                    </select>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <label class="col-sm-2 control-label" for="center">Center</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <select class="form-control" id="center" name="center">
                                                                                                                                                                                        <option value="no" selected="selected">No</option>
                                                                                                                                                                                        <option value="yes">Yes</option>
                                                                                                                                                                                    </select>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="font_family">Font Family</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="font_family" name="font_family" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="font_size">Font Size</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="font_size" name="font_size" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="line_height">Line Height</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="line_height" name="line_height" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                            <div class="form-group">
                                 <label class="col-sm-2 control-label" for="icon">Icon</label>
                                                                                                                                                                                  <div class="col-sm-10">
                                                                                                                                                                                  <input class="form-control" id="icon" name="icon" type="text" value="fa fa-chevron-right" required /><br>Ex. <b>fa fa-chevron-right</b>
                                                                                                                                                                                  <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/icons/">Icon List</a>
            </div>
                                                                                                                                                                             </div>
                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="margin_top">Margin Top</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="margin_top" name="margin_top" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="margin_bottom">Margin Bottom</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="margin_bottom" name="margin_bottom" type="text" value="" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <?php echo $animations; ?>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>


                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                <div class="col-sm-2"></div>
                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>

                                                                                                                                                                        </form>

                                                                                                                                                                        <?php
                                                                                                                                                                    } elseif ( $page == 'leap_tabs' ) {
                                                                                                                                                                        ?>
                                                                                                                                                                        <script type="text/javascript">
                                                                                                                                                                            var AddTabs = {
                                                                                                                                                                                e: '',
                                                                                                                                                                                init: function ( e ) {
                                                                                                                                                                                    AddTabs.e = e;
                                                                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                },
                                                                                                                                                                                insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                    var tabs = jQuery( '#tabs' ).val();
                                                                                                                                                                                    var style = jQuery( '#style' ).val();
                                                                                                                                                                                    var type = jQuery( '#type' ).val();

                                                                                                                                                                                    var output = '[leap_tabs ';

                                                                                                                                                                                    if ( type ) {
                                                                                                                                                                                        output += 'type="' + type + '" ';
                                                                                                                                                                                    }

                                                                                                                                                                                    if ( style ) {
                                                                                                                                                                                        output += 'style="' + style + '" ';
                                                                                                                                                                                    }

                                                                                                                                                                                    output += ']';

                                                                                                                                                                                    output += '[leap_tabs_head]';
                                                                                                                                                                                    for ( var i = 1; i <= tabs; i++ ) {
                                                                                                                                                                                        output += '[leap_tab_title]Tab ' + i + '[/leap_tab_title]';
                                                                                                                                                                                    }
                                                                                                                                                                                    output += '[/leap_tabs_head]';

                                                                                                                                                                                    output += '[leap_tabs_container]';
                                                                                                                                                                                    for ( var i = 1; i <= tabs; i++ ) {
                                                                                                                                                                                        output += '[leap_tab]Content goes here...[/leap_tab]';
                                                                                                                                                                                    }
                                                                                                                                                                                    output += '[/leap_tabs_container]';

                                                                                                                                                                                    output += '[/leap_tabs]';
                                                                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                            tinyMCEPopup.onInit.add( AddTabs.init, AddTabs );

                                                                                                                                                                        </script>
                                                                                                                                                                        <title>Add Tabs Shortcode</title>

                                                                                                                                                                        </head>
                                                                                                                                                                        <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTabs.insert( AddTabs.e )">

                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                        <label class="col-sm-2 control-label" for="tabs">Number of Tabs</label>
                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                            <input class="form-control" id="tabs" name="tabs" type="number" value="3" min="2" required />
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                            <select class="form-control" id="style" name="style">
                                                                                                                                                                                                <option value="style-1" selected="selected">Style 1</option>
                                                                                                                                                                                                <option value="style-2">Style 2</option>
                                                                                                                                                                                                <option value="style-3">Style 3</option>
                                                                                                                                                                                            </select>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                        <label class="col-sm-2 control-label" for="type">Type</label>
                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                            <select class="form-control" id="type" name="type">
                                                                                                                                                                                                <option value="horizontal" selected="selected">Horizontal</option>
                                                                                                                                                                                                <option value="vertical">Vertical</option>
                                                                                                                                                                                            </select>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>

                                                                                                                                                                                </form>


                                                                                                                                                                                <?php
                                                                                                                                                                            } elseif ( $page == 'leap_qrcode' ) {
                                                                                                                                                                                ?>
                                                                                                                                                                                <script type="text/javascript">
                                                                                                                                                                                    var AddQRCode = {
                                                                                                                                                                                        e: '',
                                                                                                                                                                                        init: function ( e ) {
                                                                                                                                                                                            AddQRCode.e = e;
                                                                                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                        },
                                                                                                                                                                                        insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                            var text = jQuery( '#text' ).val();
                                                                                                                                                                                            var width = jQuery( '#width' ).val();

                                                                                                                                                                                            var output = '[leap_qr ';

                                                                                                                                                                                            output += 'text="' + text + '" ';
                                                                                                                                                                                            output += 'width="' + width + '" ';


                                                                                                                                                                                            output += ']';

                                                                                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                            tinyMCEPopup.close();

                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                    tinyMCEPopup.onInit.add( AddQRCode.init, AddQRCode );

                                                                                                                                                                                </script>
                                                                                                                                                                                <title>Add QR Code Shortcode</title>

                                                                                                                                                                                </head>
                                                                                                                                                                                <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddQRCode.insert( AddQRCode.e )">

                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                <label class="col-sm-2 control-label" for="text">Text</label>
                                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                                    <input class="form-control" id="text" name="text" type="text" value="" />
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>

                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                <label class="col-sm-2 control-label" for="width">Width</label>
                                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                                    <input class="form-control" id="width" name="width" type="number" value="150" min="1" />
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>

                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                <div class="col-sm-2"></div>
                                                                                                                                                                                                <div class="col-sm-10">
                                                                                                                                                                                                    <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>

                                                                                                                                                                                        </form>


                                                                                                                                                                                        <?php
                                                                                                                                                                                    } elseif ( $page == 'leap_separator' ) {
                                                                                                                                                                                        ?>
                                                                                                                                                                                        <script type="text/javascript">
                                                                                                                                                                                            var AddSeparator = {
                                                                                                                                                                                                e: '',
                                                                                                                                                                                                init: function ( e ) {
                                                                                                                                                                                                    AddSeparator.e = e;
                                                                                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                },
                                                                                                                                                                                                insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                    var style = jQuery( '#style' ).val();
                                                                                                                                                                                                    var color = jQuery( '#color' ).val();
                                                                                                                                                                                                    var width = jQuery( '#width' ).val();
                                                                                                                                                                                                    var margintop = jQuery( '#margintop' ).val();
                                                                                                                                                                                                    var marginbottom = jQuery( '#marginbottom' ).val();

                                                                                                                                                                                                    var output = '[leap_separator style="' + style + '" color="' + color + '" width="' + width + '" margintop="' + margintop + '" marginbottom="' + marginbottom + '"]';

                                                                                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                            tinyMCEPopup.onInit.add( AddSeparator.init, AddSeparator );

                                                                                                                                                                                        </script>
                                                                                                                                                                                        <title>Add Separator Shortcode</title>

                                                                                                                                                                                        </head>
                                                                                                                                                                                        <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddSeparator.insert( AddSeparator.e )">

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="style" name="style">
                                                                                                                                                                                                            <option value="solid" selected="selected">Solid</option>
                                                                                                                                                                                                            <option value="dashed">Dashed</option>
                                                                                                                                                                                                            <option value="dotted">Dotted</option>
                                                                                                                                                                                                            <option value="double">Double</option>
                                                                                                                                                                                                            <option value="top-shadow">Top Shadow</option>
                                                                                                                                                                                                            <option value="bottom-shadow">Bottom Shadow</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <label class="col-sm-2 control-label" for="color">Border Color</label>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="color" name="color" type="text" />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <label class="col-sm-2 control-label" for="width">Border Width</label>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="width" name="width" type="text" />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <label class="col-sm-2 control-label" for="margintop">Margin Top</label>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="margintop" name="margintop" type="text" />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <label class="col-sm-2 control-label" for="margintop">Margin Bottom</label>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="marginbottom" name="marginbottom" type="text" />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                    <div class="form-group">
                                                                                                                                                                                                        <div class="col-sm-2"></div>
                                                                                                                                                                                                        <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>

                                                                                                                                                                                                </form>

                                                                                                                                                                                                <?php
                                                                                                                                                                                            } elseif ( $page == 'leap_list' ) {
                                                                                                                                                                                                ?>
                                                                                                                                                                                                <script type="text/javascript">
                                                                                                                                                                                                    var AddList = {
                                                                                                                                                                                                        e: '',
                                                                                                                                                                                                        init: function ( e ) {
                                                                                                                                                                                                            AddList.e = e;
                                                                                                                                                                                                            tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                        },
                                                                                                                                                                                                        insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                            var icon = jQuery( '#icon' ).val();
                                                                                                                                                                                                            var iconcolor = jQuery( '#iconcolor' ).val();

                                                                                                                                                                                                            var output = '[leap_ul]';
                                                                                                                                                                                                            output += '[leap_li icon="' + icon + '" iconcolor="' + iconcolor + '"]Item 1[/leap_li]';
                                                                                                                                                                                                            output += '[leap_li icon="' + icon + '" iconcolor="' + iconcolor + '"]Item 2[/leap_li]';
                                                                                                                                                                                                            output += '[leap_li icon="' + icon + '" iconcolor="' + iconcolor + '"]Item 3[/leap_li]';
                                                                                                                                                                                                            output += '[leap_li icon="' + icon + '" iconcolor="' + iconcolor + '"]Item 4[/leap_li]';
                                                                                                                                                                                                            output += '[leap_li icon="' + icon + '" iconcolor="' + iconcolor + '"]Item 5[/leap_li]';
                                                                                                                                                                                                            output += '[/leap_ul]';

                                                                                                                                                                                                            tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                            tinyMCEPopup.close();

                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                    tinyMCEPopup.onInit.add( AddList.init, AddList );

                                                                                                                                                                                                </script>
                                                                                                                                                                                                <title>Add List Shortcode</title>

                                                                                                                                                                                                </head>
                                                                                                                                                                                                <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                        <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddList.insert( AddList.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="icon">Icon</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="icon" name="icon" type="text" value="fa-chevron-right" required /><br>Ex. fa-<b>chevron-right</b> <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/icons/">Icon List</a>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="iconcolor">Icon color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="iconcolor" name="iconcolor" type="text" value="#000000"/> Ex. #000000
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                        </form>


                                                                                                                                                                                                        <?php
                                                                                                                                                                                                    } elseif ( $page == 'leap_tooltip' ) {
                                                                                                                                                                                                        ?>
                                                                                                                                                                                                        <script type="text/javascript">
                                                                                                                                                                                                            var AddTooltip = {
                                                                                                                                                                                                                e: '',
                                                                                                                                                                                                                init: function ( e ) {
                                                                                                                                                                                                                    AddTooltip.e = e;
                                                                                                                                                                                                                    tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                },
                                                                                                                                                                                                                insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                    var text = jQuery( '#text' ).val();
                                                                                                                                                                                                                    var tooltip = jQuery( '#tooltip' ).val();
                                                                                                                                                                                                                    var placement = jQuery( '#placement' ).val();

                                                                                                                                                                                                                    var output = '[leap_tooltip ';

                                                                                                                                                                                                                    if ( tooltip ) {
                                                                                                                                                                                                                        output += 'text="' + tooltip + '" ';
                                                                                                                                                                                                                    }

                                                                                                                                                                                                                    if ( placement ) {
                                                                                                                                                                                                                        output += 'placement="' + placement + '" ';
                                                                                                                                                                                                                    }

                                                                                                                                                                                                                    output += ']' + text + '[/leap_tooltip]';

                                                                                                                                                                                                                    tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                    tinyMCEPopup.close();

                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            tinyMCEPopup.onInit.add( AddTooltip.init, AddTooltip );

                                                                                                                                                                                                        </script>
                                                                                                                                                                                                        <title>Add List Shortcode</title>

                                                                                                                                                                                                        </head>
                                                                                                                                                                                                        <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTooltip.insert( AddTooltip.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="text">Text</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="text" name="text" type="text" value="" required />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="tooltip">Tooltip Content</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="tooltip" name="tooltip" type="text" value="" required />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="placement">Tooltip Placement</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="placement" name="placement">
                                                                                                                                                                                                            <option value="top" selected="selected">Top</option>
                                                                                                                                                                                                            <option value="bottom">Bottom</option>
                                                                                                                                                                                                            <option value="left">Left</option>
                                                                                                                                                                                                            <option value="right">Right</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                <?php
                                                                                                                                                                                                            } elseif ( $page == 'leap_testimonials' ) {
                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddTestimonials = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddTestimonials.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var NTestimonials = jQuery( '#NTestimonials' ).val();
                                                                                                                                                                                                                        var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                                                                                                                                                                        var bordercolor = jQuery( '#bordercolor' ).val();
                                                                                                                                                                                                                        var namecolor = jQuery( '#namecolor' ).val();
                                                                                                                                                                                                                        var companycolor = jQuery( '#companycolor' ).val();
                                                                                                                                                                                                                        var controls = jQuery( '#controls' ).val();

                                                                                                                                                                                                                        var output = '[leap_testimonials ';

                                                                                                                                                                                                                        output += 'backgroundcolor="' + backgroundcolor + '" ';
                                                                                                                                                                                                                        output += 'bordercolor="' + bordercolor + '" ';
                                                                                                                                                                                                                        output += 'namecolor="' + namecolor + '" ';
                                                                                                                                                                                                                        output += 'companycolor="' + companycolor + '" ';
                                                                                                                                                                                                                        output += 'controls="' + controls + '"';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        for ( var i = 1; i <= NTestimonials; i++ ) {
                                                                                                                                                                                                                            output += '[leap_testimonial name="John Doe" image="http://placehold.it/75x75" size="75x75" company="My Company" link="" target=""]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a porttitor tortor. Cras faucibus venenatis tortor. In ut diam dignissim, commodo dolor nec, sollicitudin odio. Aliquam eu ligula erat[/leap_testimonial]';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '[/leap_testimonials]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddTestimonials.init, AddTestimonials );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Testimonials</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTestimonials.insert( AddTestimonials.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundcolor">Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordercolor">Border Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordercolor" name="bordercolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="namecolor">Name Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="namecolor" name="namecolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="companycolor">Company Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="companycolor" name="companycolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="NTestimonials">Number of Testimonials</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="NTestimonials" name="NTestimonials" type="number" value="3" min="1" required />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="controls">Display Controls</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="controls" name="controls">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>

                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                    } elseif ( $page == 'leap_progress_bar' ) {
                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddProgressBar = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddProgressBar.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var label = jQuery( '#label' ).val();
                                                                                                                                                                                                                        var color = jQuery( '#color' ).val();
                                                                                                                                                                                                                        var labelcolor = jQuery( '#labelcolor' ).val();
                                                                                                                                                                                                                        var height = jQuery( '#height' ).val();
                                                                                                                                                                                                                        var bgcolor = jQuery( '#bgcolor' ).val();
                                                                                                                                                                                                                        var striped = jQuery( '#striped' ).val();
                                                                                                                                                                                                                        var animated = jQuery( '#animated' ).val();
                                                                                                                                                                                                                        var percentage = jQuery( '#percentage' ).val();

                                                                                                                                                                                                                        var output = '[leap_progress_bar ';

                                                                                                                                                                                                                        output += 'percentage="' + percentage + '" ';
                                                                                                                                                                                                                        output += 'color="' + color + '" ';
                                                                                                                                                                                                                        output += 'labelcolor="' + labelcolor + '" ';
                                                                                                                                                                                                                        output += 'height="' + height + '" ';
                                                                                                                                                                                                                        output += 'bgcolor="' + bgcolor + '" ';
                                                                                                                                                                                                                        output += 'label="' + label + '" ';
                                                                                                                                                                                                                        output += 'striped="' + striped + '" ';
                                                                                                                                                                                                                        output += 'animated="' + animated + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddProgressBar.init, AddProgressBar );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Progress Bar Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddProgressBar.insert( AddProgressBar.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="percentage">Percentage</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="percentage" name="percentage" type="number" value="25" min="1" max="100" required />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="color">Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="color" name="color" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="labelcolor">Label Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="labelcolor" name="labelcolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="height">Height</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="height" name="height" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bgcolor">Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bgcolor" name="bgcolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="label">Label</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="label" name="label" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="striped">Striped</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="striped" name="striped">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animated">Animated</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="animated" name="animated">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                            } elseif ( $page == 'leap_alert_box' ) {
                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddAlertBox = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddAlertBox.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var type = jQuery( '#type' ).val();
                                                                                                                                                                                                                        var icon = jQuery( '#icon' ).val();
                                                                                                                                                                                                                        var close = jQuery( '#close' ).val();
                                                                                                                                                                                                                        var title = jQuery( '#title' ).val();
                                                                                                                                                                                                                        var message = jQuery( '#message' ).val();

                                                                                                                                                                                                                        var output = '[leap_alert_box ';

                                                                                                                                                                                                                        output += 'title="' + title + '" ';
                                                                                                                                                                                                                        output += 'type="' + type + '" ';
                                                                                                                                                                                                                        output += 'icon="' + icon + '" ';
                                                                                                                                                                                                                        output += 'close="' + close + '" ';

                                                                                                                                                                                                                        output += ']' + message + '[/leap_alert_box]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddAlertBox.init, AddAlertBox );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Alert Box Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddAlertBox.insert( AddAlertBox.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="title" name="title" type="text" value="" required />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="message">Message</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <textarea class="form-control" id="message" name="message" value="" required ></textarea>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="type">Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="type" name="type">
                                                                                                                                                                                                            <option value="alert-warning" selected="selected">Warning</option>
                                                                                                                                                                                                            <option value="alert-danger">Error or danger</option>
                                                                                                                                                                                                            <option value="alert-success">Success</option>
                                                                                                                                                                                                            <option value="alert-info">Info</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="icon">Icon</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="icon" name="icon">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="close">Close</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="close" name="close">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                    } elseif ( $page == 'leap_fontawesome' ) {
                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddFontawesome = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddFontawesome.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var icon = jQuery( '#icon' ).val();
                                                                                                                                                                                                                        var type = jQuery( '#type' ).val();
                                                                                                                                                                                                                        var size = jQuery( '#size' ).val();
                                                                                                                                                                                                                        var iconcolor = jQuery( '#iconcolor' ).val();
                                                                                                                                                                                                                        var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                                                                                                                                                                        var bordercolor = jQuery( '#bordercolor' ).val();

                                                                                                                                                                                                                        var output = '[leap_fontawesome ';

                                                                                                                                                                                                                        // icon
                                                                                                                                                                                                                        output += 'icon="' + icon + '" ';

                                                                                                                                                                                                                        // type
                                                                                                                                                                                                                        output += 'type="' + type + '" ';

                                                                                                                                                                                                                        // size
                                                                                                                                                                                                                        output += 'size="' + size + '" ';

                                                                                                                                                                                                                        // iconcolor
                                                                                                                                                                                                                        output += 'iconcolor="' + iconcolor + '" ';

                                                                                                                                                                                                                        // backgroundcolor
                                                                                                                                                                                                                        output += 'backgroundcolor="' + backgroundcolor + '" ';

                                                                                                                                                                                                                        // bordercolor
                                                                                                                                                                                                                        output += 'bordercolor="' + bordercolor + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddFontawesome.init, AddFontawesome );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Font Awesome Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddFontawesome.insert( AddFontawesome.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="icon">Icon</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="icon" name="icon" type="text" value="adjust" /> Ex: fa-<b>adjust</b> <a target="_blank" href="http://fortawesome.github.io/Font-Awesome/icons/">Icon List</a>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="type">Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="type" name="type">
                                                                                                                                                                                                            <option value="normal" selected="selected">Normal</option>
                                                                                                                                                                                                            <option value="circle">Circle</option>
                                                                                                                                                                                                            <option value="square">Square</option>
                                                                                                                                                                                                            <option value="rounded">Rounded</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="size">Size</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="size" name="size">
                                                                                                                                                                                                            <option value="" selected="selected">Normal</option>
                                                                                                                                                                                                            <option value="lg">Large</option>
                                                                                                                                                                                                            <option value="2x">2x</option>
                                                                                                                                                                                                            <option value="3x">3x</option>
                                                                                                                                                                                                            <option value="4x">4x</option>
                                                                                                                                                                                                            <option value="5x">5x</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="iconcolor">Icon color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="iconcolor" name="iconcolor" type="text" value=""/> Ex. #333333
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundcolor">Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text" value=""/> Ex. #333333
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordercolor">Border Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordercolor" name="bordercolor" type="text" value=""/> Ex. #333333
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                            } elseif ( $page == 'leap_person' ) {
                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddPerson = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddPerson.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var name = jQuery( '#name' ).val();
                                                                                                                                                                                                                        var namecolor = jQuery( '#namecolor' ).val();
                                                                                                                                                                                                                        var picture = jQuery( '#picture' ).val();
                                                                                                                                                                                                                        var size = jQuery( '#size' ).val();
                                                                                                                                                                                                                        var type = jQuery( '#type' ).val();
                                                                                                                                                                                                                        var title = jQuery( '#title' ).val();
                                                                                                                                                                                                                        var titlecolor = jQuery( '#titlecolor' ).val();
                                                                                                                                                                                                                        var facebook = jQuery( '#facebook' ).val();
                                                                                                                                                                                                                        var twitter = jQuery( '#twitter' ).val();
                                                                                                                                                                                                                        var linkedin = jQuery( '#linkedin' ).val();
                                                                                                                                                                                                                        var dribbble = jQuery( '#dribbble' ).val();
                                                                                                                                                                                                                        var googlep = jQuery( '#googlep' ).val();
                                                                                                                                                                                                                        var email = jQuery( '#email' ).val();
                                                                                                                                                                                                                        var linktarget = jQuery( '#linktarget' ).val();
                                                                                                                                                                                                                        var content = jQuery( '#content' ).val();
                                                                                                                                                                                                                        var center = jQuery( '#center' ).val();

                                                                                                                                                                                                                        var output = '[leap_person ';

                                                                                                                                                                                                                        output += 'name="' + name + '" ';
                                                                                                                                                                                                                        output += 'namecolor="' + namecolor + '" ';
                                                                                                                                                                                                                        output += 'picture="' + picture + '" ';
                                                                                                                                                                                                                        output += 'size="' + size + '" ';
                                                                                                                                                                                                                        output += 'type="' + type + '" ';
                                                                                                                                                                                                                        output += 'title="' + title + '" ';
                                                                                                                                                                                                                        output += 'titlecolor="' + titlecolor + '" ';
                                                                                                                                                                                                                        output += 'facebook="' + facebook + '" ';
                                                                                                                                                                                                                        output += 'twitter="' + twitter + '" ';
                                                                                                                                                                                                                        output += 'linkedin="' + linkedin + '" ';
                                                                                                                                                                                                                        output += 'dribbble="' + dribbble + '" ';
                                                                                                                                                                                                                        output += 'googlep="' + googlep + '" ';
                                                                                                                                                                                                                        output += 'email="' + email + '" ';
                                                                                                                                                                                                                        output += 'linktarget="' + linktarget + '" ';
                                                                                                                                                                                                                        output += 'center="' + center + '" ';

                                                                                                                                                                                                                        output += ']' + content + '[/leap_person]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddPerson.init, AddPerson );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Person</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddPerson.insert( AddPerson.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="name">Name</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="name" name="name" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="namecolor">Name Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="namecolor" name="namecolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="picture">Picture</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="picture" name="picture" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="size">Size</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="size" name="size" type="text" value="75x75" />
                                                                                                                                                                                                            <span class="help-block">Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).</span>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="type">Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="type" name="type">
                                                                                                                                                                                                            <option value="polaroid" selected="selected">Polaroid</option>
                                                                                                                                                                                                            <option value="rounded">Rounded</option>
                                                                                                                                                                                                            <option value="circle">Circle</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="title">Title</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="title" name="title" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="titlecolor">Title Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="titlecolor" name="titlecolor" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="facebook">Facebook</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="facebook" name="facebook" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="twitter">Twitter</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="twitter" name="twitter" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="linkedin">LinkedIn</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="linkedin" name="linkedin" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="dribbble">Dribbble</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="dribbble" name="dribbble" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="googlep">Google+</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="googlep" name="googlep" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        
                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="googlep">Email</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="email" name="email" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="linktarget">Target</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="linktarget" name="linktarget">
                                                                                                                                                                                                            <option value="" selected="selected">Default</option>
                                                                                                                                                                                                            <option value="_blank">Blank</option>
                                                                                                                                                                                                            <option value="_parent">Parent</option>
                                                                                                                                                                                                            <option value="_self">Self</option>
                                                                                                                                                                                                            <option value="_top">Top</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <textarea class="form-control" id="content" name="content" value="" >Content goes here...</textarea>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="center">Center</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="center" name="center">
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_flickr' ) {
                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddFlickr = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddFlickr.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var accountid = jQuery( '#accountid' ).val();
                                                                                                                                                                                                                        var number = jQuery( '#number' ).val();
                                                                                                                                                                                                                        var orderby = jQuery( '#orderby' ).val();

                                                                                                                                                                                                                        var output = '[leap_flickr ';

                                                                                                                                                                                                                        if ( accountid ) {
                                                                                                                                                                                                                            output += 'account_id="' + accountid + '" ';
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        if ( number ) {
                                                                                                                                                                                                                            output += 'number="' + number + '" ';
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        if ( orderby ) {
                                                                                                                                                                                                                            output += 'orderby="' + orderby + '" ';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddFlickr.init, AddFlickr );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Flickr Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddFlickr.insert( AddFlickr.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="accountid">Account id</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="accountid" name="accountid" type="text" value="" required /> <span class="help-inline">get it from <a target="_blank" href="http://www.idgettr.com">idGettr</a></span>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="number">number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="number" name="number" type="number" value="5" min="1" required=""/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="orderby">Order by</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="orderby" name="orderby">
                                                                                                                                                                                                            <option value="latest" selected="selected">Latest</option>
                                                                                                                                                                                                            <option value="random">Random</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                                            } elseif ( $page == 'leap_blog' ) {
                                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddBlog = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddBlog.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var layout = jQuery( '#layout' ).val();
                                                                                                                                                                                                                        var number_posts = jQuery( '#number_posts' ).val();
                                                                                                                                                                                                                        var cats = jQuery( '#cats' ).val();
                                                                                                                                                                                                                        var excerpt = jQuery( '#excerpt' ).val();
                                                                                                                                                                                                                        var excerptlength = jQuery( '#excerptlength' ).val();
                                                                                                                                                                                                                        var meta_author = jQuery( '#meta_author' ).val();
                                                                                                                                                                                                                        var meta_categories = jQuery( '#meta_categories' ).val();
                                                                                                                                                                                                                        var meta_comments = jQuery( '#meta_comments' ).val();
                                                                                                                                                                                                                        var meta_date = jQuery( '#meta_date' ).val();
                                                                                                                                                                                                                        var meta_tags = jQuery( '#meta_tags' ).val();
                                                                                                                                                                                                                        var paging = jQuery( '#paging' ).val();
                                                                                                                                                                                                                        var share_buttons = jQuery( '#share_buttons' ).val();


                                                                                                                                                                                                                        var output = '[leap_blog ';

                                                                                                                                                                                                                        output += 'layout="' + layout + '" ';
                                                                                                                                                                                                                        output += 'number_posts="' + number_posts + '" ';
                                                                                                                                                                                                                        output += 'cats="' + cats + '" ';
                                                                                                                                                                                                                        output += 'excerpt="' + excerpt + '" ';
                                                                                                                                                                                                                        output += 'excerptlength="' + excerptlength + '" ';
                                                                                                                                                                                                                        output += 'meta_author="' + meta_author + '" ';
                                                                                                                                                                                                                        output += 'meta_categories="' + meta_categories + '" ';
                                                                                                                                                                                                                        output += 'meta_comments="' + meta_comments + '" ';
                                                                                                                                                                                                                        output += 'meta_date="' + meta_date + '" ';
                                                                                                                                                                                                                        output += 'meta_tags="' + meta_tags + '" ';
                                                                                                                                                                                                                        output += 'paging="' + paging + '" ';
                                                                                                                                                                                                                        output += 'share_buttons="' + share_buttons + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddBlog.init, AddBlog );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Blog Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddBlog.insert( AddBlog.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="layout">Layout</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="layout" name="layout">
                                                                                                                                                                                                            <option value="grid" selected="selected">Grid</option>
                                                                                                                                                                                                            <option value="classic">Classic</option>
                                                                                                                                                                                                            <option value="large">Large</option>
                                                                                                                                                                                                            <option value="medium">Medium</option>
                                                                                                                                                                                                            <option value="postformat">Post Format</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="number_posts">Posts Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="number_posts" name="number_posts" type="number" value="5" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="cats">Categories Slugs</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="cats" name="cats" type="text" value="" /> Comma separated
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="excerpt">Excerpt</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="excerpt" name="excerpt">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="excerptlength">Excerpt Length</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="excerptlength" name="excerptlength" type="text" value="55" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="meta_author">Author Meta</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="meta_author" name="meta_author">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="meta_categories">Categories Meta</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="meta_categories" name="meta_categories">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="meta_comments">Comments Meta</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="meta_comments" name="meta_comments">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="meta_date">Date Meta</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="meta_date" name="meta_date">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="meta_tags">Tags Meta</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="meta_tags" name="meta_tags">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="paging">Paging</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="paging" name="paging">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="share_buttons">Share Buttons</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="share_buttons" name="share_buttons">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">no</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>


                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>



                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_portfolio_slider' ) {
                                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddPortfolioSlider = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddPortfolioSlider.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var cats = jQuery( '#cats' ).val();
                                                                                                                                                                                                                        var num = jQuery( '#num' ).val();


                                                                                                                                                                                                                        var output = '[leap_portfolio_slider ';

                                                                                                                                                                                                                        output += 'cats="' + cats + '" ';
                                                                                                                                                                                                                        output += 'num="' + num + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddPortfolioSlider.init, AddPortfolioSlider );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Portfolio Slider Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddPortfolioSlider.insert( AddPortfolioSlider.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="cats">Categories slugs</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="cats" name="cats" type="text" value="" /> Comma separated
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="num">Posts Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="num" name="num" type="number" value="5" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                                                            } elseif ( $page == 'leap_portfolio' ) {
                                                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddPortfolio = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddPortfolio.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var layout = jQuery( '#layout' ).val();
                                                                                                                                                                                                                        var cats = jQuery( '#cats' ).val();
                                                                                                                                                                                                                        var num = jQuery( '#num' ).val();
                                                                                                                                                                                                                        var without_featured_image = jQuery( '#without_featured_image' ).val();
                                                                                                                                                                                                                        var order = jQuery( '#order' ).val();
                                                                                                                                                                                                                        var orderby = jQuery( '#orderby' ).val();
                                                                                                                                                                                                                        var filter = jQuery( '#filter' ).val();
                                                                                                                                                                                                                        var titles = jQuery( '#titles' ).val();
                                                                                                                                                                                                                        var categories = jQuery( '#categories' ).val();
                                                                                                                                                                                                                        var descriptions = jQuery( '#descriptions' ).val();
                                                                                                                                                                                                                        var excerptlength = jQuery( '#excerptlength' ).val();
                                                                                                                                                                                                                        var readmore_button = jQuery( '#readmore_button' ).val();
                                                                                                                                                                                                                        var visit_button = jQuery( '#visit_button' ).val();
                                                                                                                                                                                                                        var separator = jQuery( '#separator' ).val();
                                                                                                                                                                                                                        var paging = jQuery( '#paging' ).val();


                                                                                                                                                                                                                        var output = '[leap_portfolio ';

                                                                                                                                                                                                                        output += 'layout="' + layout + '" ';
                                                                                                                                                                                                                        output += 'cats="' + cats + '" ';
                                                                                                                                                                                                                        output += 'num="' + num + '" ';
                                                                                                                                                                                                                        output += 'without_featured_image="' + without_featured_image + '" ';
                                                                                                                                                                                                                        output += 'order="' + order + '" ';
                                                                                                                                                                                                                        output += 'orderby="' + orderby + '" ';
                                                                                                                                                                                                                        output += 'filter="' + filter + '" ';
                                                                                                                                                                                                                        output += 'titles="' + titles + '" ';
                                                                                                                                                                                                                        output += 'categories="' + categories + '" ';
                                                                                                                                                                                                                        output += 'descriptions="' + descriptions + '" ';
                                                                                                                                                                                                                        output += 'excerptlength="' + excerptlength + '" ';
                                                                                                                                                                                                                        output += 'readmore_button="' + readmore_button + '" ';
                                                                                                                                                                                                                        output += 'visit_button="' + visit_button + '" ';
                                                                                                                                                                                                                        output += 'separator="' + separator + '" ';
                                                                                                                                                                                                                        output += 'paging="' + paging + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddPortfolio.init, AddPortfolio );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Portfolio Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddPortfolio.insert( AddPortfolio.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="layout">Layout</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="layout" name="layout">
                                                                                                                                                                                                            <option value="grid" selected="selected">Grid</option>
                                                                                                                                                                                                            <option value="1col">One Column</option>
                                                                                                                                                                                                            <option value="2col">Two Column</option>
                                                                                                                                                                                                            <option value="3col">Three Column</option>
                                                                                                                                                                                                            <option value="4col">Four Column</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="cats">Categories slugs</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="cats" name="cats" type="text" value="" /> Comma separated
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="num">Posts Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="num" name="num" type="number" value="5" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="without_featured_image">Display items without featured image</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="without_featured_image" name="without_featured_image">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="order">Order</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="order" name="order">
                                                                                                                                                                                                            <option value="DESC" selected="selected">Descending</option>
                                                                                                                                                                                                            <option value="ASC">Ascending</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="orderby">Order By</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="orderby" name="order">
                                                                                                                                                                                                            <option value="date" selected="selected">Date</option>
                                                                                                                                                                                                            <option value="title">Title</option>
                                                                                                                                                                                                            <option value="rand">Random</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="filter">Display Filter</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="filter" name="filter">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="titles">Show Titles</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="titles" name="titles">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="categories">Show Categories</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="categories" name="categories">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="descriptions">Show Descriptions</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="descriptions" name="descriptions">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="excerptlength">Excerpt Length</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="excerptlength" name="excerptlength" type="text" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="readmore_button">Display Read More Button</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="readmore_button" name="readmore_button">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="visit_button">Display Visit Project Button</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="visit_button" name="visit_button">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="separator">Separator</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="separator" name="separator">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="paging">Paging</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="paging" name="paging">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>



                                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_rss' ) {
                                                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddRss = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddRss.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var number = jQuery( '#number' ).val();
                                                                                                                                                                                                                        var feed = jQuery( '#feed' ).val();
                                                                                                                                                                                                                        var date = jQuery( '#date' ).val();

                                                                                                                                                                                                                        var output = '[leap_rss ';

                                                                                                                                                                                                                        if ( number ) {
                                                                                                                                                                                                                            output += 'number="' + number + '" ';
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        if ( feed ) {
                                                                                                                                                                                                                            output += 'feed="' + feed + '" ';
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        if ( date ) {
                                                                                                                                                                                                                            output += 'date="' + date + '" ';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddRss.init, AddRss );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add RSS Feeds Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddRss.insert( AddRss.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="number">Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="number" name="number" type="number" value="5" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="feed">Feed</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="feed" name="feed" type="url" value="" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="date">Display date</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="date" name="date">
                                                                                                                                                                                                            <option value="yes" selected="selected">Yes</option>
                                                                                                                                                                                                            <option value="no">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>



                                                                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                                                                            } elseif ( $page == 'leap_gap' ) {
                                                                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddGap = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddGap.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var height = jQuery( '#height' ).val();

                                                                                                                                                                                                                        var output = '[leap_gap ';

                                                                                                                                                                                                                        output += 'height="' + height + '" ';

                                                                                                                                                                                                                        output += ']';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddGap.init, AddGap );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Gap Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddGap.insert( AddGap.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="height">Height</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="height" name="height" type="text" value="20px" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_table' ) {
                                                                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddTable = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddTable.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var style = jQuery( '#style' ).val();
                                                                                                                                                                                                                        var cols = jQuery( '#cols' ).val();
                                                                                                                                                                                                                        var rows = jQuery( '#rows' ).val();
                                                                                                                                                                                                                        var striped = jQuery( '#striped' ).val();
                                                                                                                                                                                                                        var bordered = jQuery( '#bordered' ).val();
                                                                                                                                                                                                                        var hover = jQuery( '#hover' ).val();
                                                                                                                                                                                                                        var condensed = jQuery( '#condensed' ).val();
                                                                                                                                                                                                                        var responsive = jQuery( '#responsive' ).val();

                                                                                                                                                                                                                        var calsses = '';
                                                                                                                                                                                                                        var output = '';

                                                                                                                                                                                                                        if ( striped === 'yes' ) {
                                                                                                                                                                                                                            calsses += 'table-striped ';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        if ( bordered === 'yes' ) {
                                                                                                                                                                                                                            calsses += 'table-bordered ';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        if ( hover === 'yes' ) {
                                                                                                                                                                                                                            calsses += 'table-hover ';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        if ( condensed === 'yes' ) {
                                                                                                                                                                                                                            calsses += 'table-condensed ';
                                                                                                                                                                                                                        }


                                                                                                                                                                                                                        if ( responsive === 'yes' ) {
                                                                                                                                                                                                                            output += '<div class="table-responsive">';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '<table class="table ' + calsses + ' ' + style + ' leap-table"><thead><tr>';

                                                                                                                                                                                                                        for ( var i = 1; i <= cols; i++ ) {
                                                                                                                                                                                                                            output += '<th>Column Header</th>';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '</tr></thead><tbody>';

                                                                                                                                                                                                                        for ( var i = 1; i <= rows; i++ ) {
                                                                                                                                                                                                                            output += '<tr>';
                                                                                                                                                                                                                            for ( var j = 1; j <= cols; j++ ) {
                                                                                                                                                                                                                                output += '<td>Cell Data</td>';
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            output += '</tr>';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '</tbody></table>';

                                                                                                                                                                                                                        if ( responsive === 'yes' ) {
                                                                                                                                                                                                                            output += '</div>';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddTable.init, AddTable );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Table</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddTable.insert( AddTable.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="style">Style</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="style" name="style">
                                                                                                                                                                                                            <option value="style-1" selected="selected">Style 1</option>
                                                                                                                                                                                                            <option value="style-2">Style 2</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="cols">Column numbers</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="cols" name="cols" type="number" value="3" min="1" required/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="rows">Row numbers</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="rows" name="rows" type="number" value="3" min="1" required/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="striped">Striped</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="striped" name="striped">
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordered">Bordered</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="bordered" name="bordered">
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="hover">Hover</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="hover" name="hover">
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="condensed">Condensed</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="condensed" name="condensed">
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="responsive">Responsive</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="responsive" name="responsive">
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                                                                                            } elseif ( $page == 'leap_clients' ) {
                                                                                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddClients = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddClients.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var clients = jQuery( '#clients' ).val();

                                                                                                                                                                                                                        var output = '[leap_clients]';

                                                                                                                                                                                                                        for ( var i = 1; i <= clients; i++ ) {
                                                                                                                                                                                                                            output += '[leap_client link="" linktarget="" image=""]';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '[/leap_clients]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddClients.init, AddClients );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Clients Slider Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddClients.insert( AddClients.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="clients">Clients number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="clients" name="clients" type="number" value="5" min="1" required/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_full_width' ) {
                                                                                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddFullWidth = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddFullWidth.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                                                                                                                                                                        var backgroundimage = jQuery( '#backgroundimage' ).val();
                                                                                                                                                                                                                        var backgroundrepeat = jQuery( '#backgroundrepeat' ).val();
                                                                                                                                                                                                                        var backgroundposition = jQuery( '#backgroundposition' ).val();
                                                                                                                                                                                                                        var backgroundattachment = jQuery( '#backgroundattachment' ).val();
                                                                                                                                                                                                                        var parallax = jQuery( '#parallax' ).val();
                                                                                                                                                                                                                        var bordersize = jQuery( '#bordersize' ).val();
                                                                                                                                                                                                                        var bordercolor = jQuery( '#bordercolor' ).val();
                                                                                                                                                                                                                        var borderstyle = jQuery( '#borderstyle' ).val();
                                                                                                                                                                                                                        var paddingtop = jQuery( '#paddingtop' ).val();
                                                                                                                                                                                                                        var paddingbottom = jQuery( '#paddingbottom' ).val();
                                                                                                                                                                                                                        var contentpaddingleft = jQuery( '#contentpaddingleft' ).val();
                                                                                                                                                                                                                        var contentpaddingright = jQuery( '#contentpaddingright' ).val();
                                                                                                                                                                                                                        var customClass = jQuery( '#class' ).val();
                                                                                                                                                                                                                        var customId = jQuery( '#id' ).val();
                                                                                                                                                                                                                        var content = jQuery( '#content' ).val();
                                                                                                                                                                                                                        var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                                                                                                                        var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                                                                                                                        var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                                                                                                                        var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                                                                                                                        var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                                                                                                                        var output = '[leap_fullwidth backgroundcolor="' + backgroundcolor + '" backgroundimage="' + backgroundimage + '" backgroundrepeat="' + backgroundrepeat + '" backgroundposition="' + backgroundposition + '" backgroundattachment="' + backgroundattachment + '" parallax="' + parallax + '" bordersize="' + bordersize + '" bordercolor="' + bordercolor + '" borderstyle="' + borderstyle + '" paddingtop="' + paddingtop + '" paddingbottom="' + paddingbottom + '" contentpaddingleft="' + contentpaddingleft + '" contentpaddingright="' + contentpaddingright + '" class="' + customClass + '" id="' + customId + '" animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]' + content + '[/leap_fullwidth]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddFullWidth.init, AddFullWidth );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Full Width Container Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddFullWidth.insert( AddFullWidth.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundcolor">Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundimage">Background Image</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="backgroundimage" name="backgroundimage" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundrepeat">Background Repeat</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="backgroundrepeat" id="backgroundrepeat" class="form-control">
                                                                                                                                                                                                            <option value="no-repeat" selected="selected" >No Repeat</option>
                                                                                                                                                                                                            <option value="repeat">Repeat Vertically and Horizontally</option>
                                                                                                                                                                                                            <option value="repeat-x">Repeat Horizontally</option>
                                                                                                                                                                                                            <option value="repeat-y">Repeat Vertically</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundposition">Background Position</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="backgroundposition" id="backgroundposition" class="form-control">
                                                                                                                                                                                                            <option value="left top" selected="selected">Left Top</option>
                                                                                                                                                                                                            <option value="left center">Left Center</option>
                                                                                                                                                                                                            <option value="left bottom">Left Bottom</option>
                                                                                                                                                                                                            <option value="right top">Right Top</option>
                                                                                                                                                                                                            <option value="right center">Right Center</option>
                                                                                                                                                                                                            <option value="right bottom">Right Bottom</option>
                                                                                                                                                                                                            <option value="center top">Center Top</option>
                                                                                                                                                                                                            <option value="center center">Center Center</option>
                                                                                                                                                                                                            <option value="center bottom">Center Bottom</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundattachment">Background Attachment</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="backgroundattachment" id="backgroundattachment" class="form-control">
                                                                                                                                                                                                            <option value="scroll" selected="selected">Scroll</option>
                                                                                                                                                                                                            <option value="fixed">Fixed</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="parallax">Parallax Background</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="parallax" id="parallax" class="form-control">
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordersize">Border Size</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordersize" name="bordersize" value="0px" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordercolor">Border Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordercolor" name="bordercolor" value="" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="borderstyle">Border Style</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="borderstyle" id="borderstyle" class="form-control">
                                                                                                                                                                                                            <option value="solid">Solid</option>
                                                                                                                                                                                                            <option value="dashed">Dashed</option>
                                                                                                                                                                                                            <option value="dotted">Dotted</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="paddingtop">Padding Top</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="paddingtop" name="paddingtop" value="20px" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="paddingbottom">Padding Bottom</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="paddingbottom" name="paddingbottom" value="20px" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="contentpaddingleft">Content Padding Left</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="contentpaddingleft" name="contentpaddingleft" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="contentpaddingright">Content Padding Right</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="contentpaddingright" name="contentpaddingright" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="class">Class</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="class" name="class" value="" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="id">Id</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="id" name="id" value="" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="content">Content</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <textarea class="form-control" id="content" name="content">Content Goes Here</textarea>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                                                                                                                                                            <?php echo $animations; ?>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>


                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>


                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                                                <?php
                                                                                                                                                                                                                                                                                                                            } elseif ( $page == 'leap_image' ) {
                                                                                                                                                                                                                                                                                                                                ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddImage = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddImage.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var image = jQuery( '#image' ).val();
                                                                                                                                                                                                                        var imagealt = jQuery( '#imagealt' ).val();
                                                                                                                                                                                                                        var width = jQuery( '#width' ).val();
                                                                                                                                                                                                                        var height = jQuery( '#height' ).val();
                                                                                                                                                                                                                        var align = jQuery( '#align' ).val();
                                                                                                                                                                                                                        var lightbox = jQuery( '#lightbox' ).val();
                                                                                                                                                                                                                        var bordersize = jQuery( '#bordersize' ).val();
                                                                                                                                                                                                                        var bordercolor = jQuery( '#bordercolor' ).val();
                                                                                                                                                                                                                        var borderstyle = jQuery( '#borderstyle' ).val();
                                                                                                                                                                                                                        var padding = jQuery( '#padding' ).val();
                                                                                                                                                                                                                        var margintop = jQuery( '#margintop' ).val();
                                                                                                                                                                                                                        var marginright = jQuery( '#marginright' ).val();
                                                                                                                                                                                                                        var marginbottom = jQuery( '#marginbottom' ).val();
                                                                                                                                                                                                                        var marginleft = jQuery( '#marginleft' ).val();
                                                                                                                                                                                                                        var backgroundcolor = jQuery( '#backgroundcolor' ).val();
                                                                                                                                                                                                                        var customClass = jQuery( '#customClass' ).val();
                                                                                                                                                                                                                        var animationtype = jQuery( '#animationtype' ).val();
                                                                                                                                                                                                                        var animationspeed = jQuery( '#animationspeed' ).val();
                                                                                                                                                                                                                        var animationdelay = jQuery( '#animationdelay' ).val();
                                                                                                                                                                                                                        var animationoffset = jQuery( '#animationoffset' ).val();
                                                                                                                                                                                                                        var animationiteration = jQuery( '#animationiteration' ).val();

                                                                                                                                                                                                                        var output = '[leap_image image="' + image + '" imagealt="' + imagealt + '" width="' + width + '" height="' + height + '" align="' + align + '" lightbox="' + lightbox + '" bordersize="' + bordersize + '" bordercolor="' + bordercolor + '" borderstyle="' + borderstyle + '" padding="' + padding + '" margintop="' + margintop + '" marginright="' + marginright + '" marginbottom="' + marginbottom + '" marginleft="' + marginleft + '" backgroundcolor="' + backgroundcolor + '" class="' + customClass + '" animationtype="' + animationtype + '" animationspeed="' + animationspeed + '" animationdelay="' + animationdelay + '" animationoffset="' + animationoffset + '" animationiteration="' + animationiteration + '" ]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddImage.init, AddImage );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Image Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddImage.insert( AddImage.e )">

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="image">Image</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="image" name="image" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="imagealt">Image Alt Text</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="imagealt" name="imagealt" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="width">Image Width</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="width" name="width" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="height">Image Height</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="height" name="height" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="align">Align</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="align" id="align" class="form-control">
                                                                                                                                                                                                            <option value="none" selected="selected">None</option>
                                                                                                                                                                                                            <option value="right">Right</option>
                                                                                                                                                                                                            <option value="left">Left</option>
                                                                                                                                                                                                            <option value="center">Center</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="lightbox">Light Box</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="lightbox" id="lightbox" class="form-control">
                                                                                                                                                                                                            <option value="no" selected="selected">No</option>
                                                                                                                                                                                                            <option value="yes">Yes</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordersize">Border Size</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordersize" name="bordersize" value="0px" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="bordercolor">Border Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="bordercolor" name="bordercolor" value="" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="borderstyle">Border Style</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select name="borderstyle" id="borderstyle" class="form-control">
                                                                                                                                                                                                            <option value="solid">Solid</option>
                                                                                                                                                                                                            <option value="dashed">Dashed</option>
                                                                                                                                                                                                            <option value="dotted">Dotted</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="padding">Padding</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="padding" name="padding" value="0px" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="margintop">Margin top</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="margintop" name="margintop" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="marginright">Margin Right</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="marginright" name="marginright" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="marginbottom">Margin Bottom</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="marginbottom" name="marginbottom" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="marginleft">Margin Left</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="marginleft" name="marginleft" value="" type="text"/> In pixels
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="backgroundcolor">Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="backgroundcolor" name="backgroundcolor" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="customClass">Custom Class</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="customClass" name="customClass" value="" type="text"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationtype">Animation Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                                                                                                                                                                    <?php echo $animations; ?>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>


                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationspeed">Animation Speed</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationspeed" name="animationspeed" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationdelay">Animation Delay</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationdelay" name="animationdelay" type="number" value="" min="1" /> In seconds
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationiteration">Animation Iteration</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationiteration" name="animationiteration" type="number" value="" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group" >
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="animationoffset">Animation Offset</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="animationoffset" name="animationoffset" type="number" value="" min="1" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>


                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                                                                                    } elseif ( $page == 'leap_pricing-table' ) {
                                                                                                                                                                                                                                                                                                                                        ?>
                                                                                                                                                                                                            <script type="text/javascript">
                                                                                                                                                                                                                var AddPricingTable = {
                                                                                                                                                                                                                    e: '',
                                                                                                                                                                                                                    init: function ( e ) {
                                                                                                                                                                                                                        AddPricingTable.e = e;
                                                                                                                                                                                                                        tinyMCEPopup.resizeToInnerSize();
                                                                                                                                                                                                                    },
                                                                                                                                                                                                                    insert: function createGalleryShortcode( e ) {
                                                                                                                                                                                                                        var type = jQuery( '#type' ).val();
                                                                                                                                                                                                                        var headerbackgroundcolor = jQuery( '#headerbackgroundcolor' ).val();
                                                                                                                                                                                                                        var headertextcolor = jQuery( '#headertextcolor' ).val();
                                                                                                                                                                                                                        var pricingbackgroundcolor = jQuery( '#pricingbackgroundcolor' ).val();
                                                                                                                                                                                                                        var pricingtextcolor = jQuery( '#pricingtextcolor' ).val();
                                                                                                                                                                                                                        var pricetextcolor = jQuery( '#pricetextcolor' ).val();
                                                                                                                                                                                                                        var oddbackgroundcolor = jQuery( '#oddbackgroundcolor' ).val();
                                                                                                                                                                                                                        var oddtextcolor = jQuery( '#oddtextcolor' ).val();
                                                                                                                                                                                                                        var evenbackgroundcolor = jQuery( '#evenbackgroundcolor' ).val();
                                                                                                                                                                                                                        var eventextcolor = jQuery( '#eventextcolor' ).val();
                                                                                                                                                                                                                        var footerbackgroundcolor = jQuery( '#footerbackgroundcolor' ).val();
                                                                                                                                                                                                                        var footertextcolor = jQuery( '#footertextcolor' ).val();
                                                                                                                                                                                                                        var columnbordercolor = jQuery( '#columnbordercolor' ).val();
                                                                                                                                                                                                                        var dividercolor = jQuery( '#dividercolor' ).val();
                                                                                                                                                                                                                        var hovercolor = jQuery( '#hovercolor' ).val();
                                                                                                                                                                                                                        var cols = jQuery( '#cols' ).val();
                                                                                                                                                                                                                        var rows = jQuery( '#rows' ).val();
                                                                                                                                                                                                                        var featured = '';

                                                                                                                                                                                                                        var output = '[leap_pricing_table type="' + type + '" headerbackgroundcolor="' + headerbackgroundcolor + '" headertextcolor="' + headertextcolor + '" pricingbackgroundcolor="' + pricingbackgroundcolor + '" pricingtextcolor="' + pricingtextcolor + '" pricetextcolor="' + pricetextcolor + '" oddbackgroundcolor="' + oddbackgroundcolor + '" oddtextcolor="' + oddtextcolor + '" evenbackgroundcolor="' + evenbackgroundcolor + '" eventextcolor="' + eventextcolor + '" footerbackgroundcolor="' + footerbackgroundcolor + '" footertextcolor="' + footertextcolor + '" hovercolor="' + hovercolor + '" dividercolor="' + dividercolor + '" columnbordercolor="' + columnbordercolor + '"]';

                                                                                                                                                                                                                        for ( var i = 1; i <= cols; i++ ) {
                                                                                                                                                                                                                            if ( i == 1 ) {
                                                                                                                                                                                                                                featured = 'yes';
                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                featured = 'no';
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            output += '[leap_pricing_column title="Title ' + i + '" featured="' + featured + '"]';
                                                                                                                                                                                                                            output += '[leap_pricing_price currency="$" price="99.99" time="monthly"][/leap_pricing_price]';
                                                                                                                                                                                                                            for ( var j = 1; j <= rows; j++ ) {
                                                                                                                                                                                                                                output += '[leap_pricing_row]Feature ' + j + '[/leap_pricing_row]';
                                                                                                                                                                                                                            }

                                                                                                                                                                                                                            output += '[leap_pricing_footer]Sign Up[/leap_pricing_footer]';
                                                                                                                                                                                                                            output += '[/leap_pricing_column]';
                                                                                                                                                                                                                        }

                                                                                                                                                                                                                        output += '[/leap_pricing_table]';

                                                                                                                                                                                                                        tinyMCEPopup.execCommand( 'mceReplaceContent', false, output );
                                                                                                                                                                                                                        tinyMCEPopup.close();

                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                tinyMCEPopup.onInit.add( AddPricingTable.init, AddPricingTable );

                                                                                                                                                                                                            </script>
                                                                                                                                                                                                            <title>Add Pricing Table Shortcode</title>

                                                                                                                                                                                                            </head>
                                                                                                                                                                                                            <body style="padding-top: 20px;"><div class="container">

                                                                                                                                                                                                            <form class="form-horizontal" id="GalleryShortcode" onsubmit="javascript:AddPricingTable.insert( AddPricingTable.e )">

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="type">Type</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <select class="form-control" id="type" name="type">
                                                                                                                                                                                                            <option value="1" selected="selected">1</option>
                                                                                                                                                                                                            <option value="2">2</option>
                                                                                                                                                                                                            </select>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Header Row -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="headerbackgroundcolor">Header Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="headerbackgroundcolor" name="headerbackgroundcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="headertextcolor">Header Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="headertextcolor" name="headertextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Pricing Row -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="pricingbackgroundcolor">Pricing Row Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="pricingbackgroundcolor" name="pricingbackgroundcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="pricingtextcolor">Pricing Row Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="pricingtextcolor" name="pricingtextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="pricetextcolor">Price Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="pricetextcolor" name="pricetextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Odd Row -->
                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="oddbackgroundcolor">Odd Row Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="oddbackgroundcolor" name="oddbackgroundcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="oddtextcolor">Odd Row Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="oddtextcolor" name="oddtextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Even Row -->
                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="evenbackgroundcolor">Even Row Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="evenbackgroundcolor" name="evenbackgroundcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="eventextcolor">Even Row Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="eventextcolor" name="eventextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Footer Row -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="footerbackgroundcolor">Footer Background Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="footerbackgroundcolor" name="footerbackgroundcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="footertextcolor">Footer Text Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="footertextcolor" name="footertextcolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Column Border Color -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="columnbordercolor">Column Border Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="columnbordercolor" name="columnbordercolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Column Border Color -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="hovercolor">Hover Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="hovercolor" name="hovercolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <!-- Column Border Color -->

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="dividercolor">Divider Color</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="dividercolor" name="dividercolor" type="text"/> <small>ex. #ffffff</small>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="cols">Columns/Packages Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="cols" name="cols" type="number" value="3" min="1"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <label class="col-sm-2 control-label" for="rows">Rows/Features Number</label>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="form-control" id="rows" name="rows" type="number" value="3" min="1"/>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            <div class="form-group">
                                                                                                                                                                                                            <div class="col-sm-2"></div>
                                                                                                                                                                                                            <div class="col-sm-10">
                                                                                                                                                                                                            <input class="btn btn-primary pull-right" type="submit" value="Insert into post" />
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            </div>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                                                                                                                                                            <?php } ?>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                        <script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
                                                                                                                                                                                                        </body>
                                                                                                                                                                                                        </html>